## 1.1.14 — Shared model contract

- Follow LOOK active model live on every frame and inference.
- Ask, Workstation, and Ambient identify `shared` vs explicit `override`.
- `--model` remains the deliberate per-session escape hatch.

## 1.1.13 — Live LOOK model selection

- Follow LOOK's currently selected model live unless `--model` was explicitly supplied.
- Ambient telemetry and Workstation views display the current Oracle model, not the startup argument snapshot.

## 1.1.12 — Interactive submit queue

- A/Ask and X/Workstation no longer silently ignore Enter while background Oracle work is active.
- Queue operator submissions behind the current call and make that queue visible.
- Preserve input when Oracle is offline.
- Bound background Oracle HTTP calls to 18 seconds.
- Inherit LOOK's selected model by default to avoid unnecessary shared-GPU model swapping.

## 1.1.11 — LOOK host inheritance

- Default Ollama URL now comes from LOOK's selected host.
- Explicit `--ollama` remains an override.
- Localhost remains the final fallback.

## 1.1.10 — Child shell ownership title

- Escaping from Future Crash into its embedded interactive shell now marks the terminal as `◌ FUTURE CRASH · SHELL`.
- Returning to Future Crash restores `● FUTURE CRASH`.
- No simulation, Oracle, Signal, memory, or host-tool behavior changed.

## 1.1.9 — Terminal ownership title

- Future Crash marks the terminal/tab title as `● FUTURE CRASH` while active.
- Restores a neutral LOOK shell title on exit.
- No Oracle, memory, Signal, or permission behavior changed.

## 1.1.8 — Polite Oracle

- Future Crash now coordinates inference capacity with LOOK Living AI when available.
- Ask/Workstation requests get interactive leases.
- Ambient observations, automatic fortunes, scheduled Threads, and FC memory folding yield to queued/interactive LOOK work.
- Personality, memory, host authority, and Signal behavior remain independent.
- No LOOK dependency: direct standalone Ollama behavior remains available.

## 1.1.7 — Dedicated Signal compiler

- Signal requests bypass Workstation reasoning and compile directly with `think=false`.
- Signal compile/repair budget: 1200 tokens; Workstation: 1600; Ask: 400; normal Threads: 300.
- Visual Threads preserve verified host receipts while compiling display output.
- Signal compiler context is isolated from unrelated conversation and memory chatter.

## 1.1.7 — Dedicated Signal compiler

- Signal requests bypass Workstation reasoning and compile directly with `think=false`.
- Signal compile/repair budget: 1200 tokens; Workstation: 1600; Ask: 400; normal Threads: 300.
- Visual Threads preserve verified host receipts while compiling display output.
- Signal compiler context is isolated from unrelated conversation and memory chatter.

## 1.1.6 — Visible background work + Signal compiler headroom

- Added a persistent cyan half-circle activity indicator, animated by the existing Future Crash render loop.
- The indicator follows Oracle work across UI views and names the current operation.
- Signal compiler repair output increased from 64 to 600 tokens, enough for multi-frame `SPRITE` + `BARS` programs.
- Signal repair now disables model reasoning and spends its generation budget directly on the parseable Signal artifact.

## 1.1.5 — Signal protocol completion

- Visual requests now require a parseable Signal payload, with one automatic silent repair pass on failure.
- Visual Threads no longer expose model planning chatter as their completed update.
- Lowercase Workstation key-hint typography.

## 1.1.3

- Fix `fallback_dream()` Signal receipt crash by using the shared receipt stats schema.

# Future Crash changelog

## 1.1.2 — raster Signal Field

- Adds transparent-space `SPRITE` blocks for compact model-authored character art.
- Adds normalized `BARS` for EQ, meter, spectrum, and dashboard-style rendering.
- Expands Signal instructions around the semantic/vector/raster mental model.
- Enriches bounded Signal receipts with mode, occupancy, and nonempty-cell feedback.


## 1.1.1 — Signal wiring fix

- Fixes hidden-thinking Signal blocks being discarded before rendering.
- Restores generous split-screen Signal layout and adds Dream fallback rendering.


## 1.1.0 — expressive Signal Field

- Signal becomes a native output channel with persistent bounded render feedback.
- Adds FPS/FRAME animation and [D] Signal Dream thread preset.
- Expands bounded recent memory to eight Workstation exchanges.


## 1.0.4 — bottom anchoring

- Restores maximum TELEMETRY/SIGNAL height while keeping the fixed Fortune block and menu pinned to the bottom.


## 1.0.3 — Fortune visual polish

- Fixed-height three-line Fortune body.
- Fortune output may use up to 36 words and rejects remaining instruction paraphrase leakage.


## 1.0.2 — artifact hardening

- Runtime version now reports 1.0.2.
- Fortune/ambient output fails closed to local seeds when the model returns reasoning instead of a final artifact.


## 1.0.1 — final-only micro-generation

- Strips structured/tagged/orphaned model reasoning before displaying Future Crash output.
- Adds a dedicated application personality file.


## 1.0.0 — unified component baseline

- Establishes Future Crash 1.0.0 as the component baseline inside Future Crash + LOOK 1.2.0.
- Keeps the canonical `future-crash` launcher plus `fc` / `rst` shell shortcuts.
- Shares LOOK's selected Ollama model and host.
- Prevents accidental recursive Future Crash sessions; `--nested` remains explicit.
- No personality/runtime redesign in this release; this is a clean versioning baseline.

## 1.1.4

- Signal framebuffer programs persist until replaced/cleared unless `TTL` is explicitly supplied.
- Host renderer adds an independent CRT scan pass while frame animations continue at their own `FPS`.
- Signal-oriented prompts now reliably trigger the model's render-language instruction, including animation requirements.
