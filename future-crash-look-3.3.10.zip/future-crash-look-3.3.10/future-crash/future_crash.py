#!/usr/bin/env python3
"""
FUTURE CRASH // ZERO
One process. One model. One terminal. Zero dependencies.

Mac/Linux:
    python3 future_crash.py --model qwen3:4b
    python3 future_crash.py --model gemma3:4b
    python3 future_crash.py --model llama3.2:3b

Optional:
    --ollama http://127.0.0.1:11434
    --fps 12
    --no-ai-ambient

Controls:
    A   quick Ask
    X   Workstation conversation
    F   new fortune
    P   panic
    R   refresh observation
    Q   quit

The terminal is the idle state. The assistant is the machine underneath it.
"""

from __future__ import annotations

import argparse
import json
import math
import struct
import tempfile
import wave
import os
os.environ["FUTURE_CRASH_ACTIVE"]="1"
import queue
import random
import re
import select
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import termios
import threading
import time
import tty
import urllib.error
import urllib.request
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

ESC = "\x1b"
CSI = ESC + "["

# ---------- Palette ----------

RESET = CSI + "0m"
BOLD = CSI + "1m"
DIM = CSI + "2m"
GREEN = CSI + "38;5;121m"
GREEN2 = CSI + "38;5;78m"
CYAN = CSI + "38;5;117m"
AMBER = CSI + "38;5;221m"
MAGENTA = CSI + "38;5;213m"
RED = CSI + "38;5;203m"
WHITE = CSI + "38;5;255m"
GRAY = CSI + "38;5;245m"
DARK = CSI + "38;5;239m"

VERSION = "1.1.14"
GLYPHS = "0123456789ABCDEF"
SPARKS = "▁▂▃▄▅▆▇█"

FORTUNES = [
    "A sufficiently patient machine eventually becomes furniture.",
    "The difficult bug is currently pretending to be a design decision.",
    "Today is favorable for backups and unfavorable for assumptions.",
    "A small uncertainty has requested a much larger office.",
    "You will solve the problem shortly after blaming the wrong subsystem.",
    "The universe recommends saving your work before testing its sense of humor.",
    "A quiet terminal is only gathering material.",
    "Before debugging the universe, reproduce the universe.",
    "The shortest path between two bugs passes through a third bug.",
    "A warning ignored twice becomes interface decoration.",
    "Some doors open automatically; others require better error messages.",
    "Your next good idea is currently disguised as an inconvenience.",
    "The machine favors patience, backups, and clearly named variables.",
    "A mysterious result is often a familiar assumption wearing a hat.",
    "Today's impossible task has been downgraded to merely annoying.",
    "The future rewards those who save before experimenting.",
    "One elegant deletion is worth several clever additions.",
    "Beware the configuration file that describes its own replacement.",
    "A stable system is a temporary agreement among moving parts.",
    "The answer is nearby, but currently facing away.",
    "The universe has accepted your input without validating it.",
    "Good naming prevents minor hauntings.",
    "A problem measured becomes a problem with paperwork.",
    "The next reboot will remember nothing and imply otherwise.",
    "A process observed too closely may begin producing documentation.",
    "The bug you seek has already renamed itself.",
    "A careful backup is optimism with evidence.",
    "Never trust a progress bar that has learned confidence.",
    "You will soon discover why that value was hard-coded.",
    "An undocumented feature is merely a bug with tenure.",
    "Good tools disappear into the work. Great tools occasionally tell fortunes.",
    "A system can be deterministic and still hold a grudge.",
    "Today favors small functions and reversible decisions.",
    "A successful experiment is one that leaves useful wreckage.",
    "Your future self has requested clearer comments.",
    "A machine left running long enough will accumulate mythology.",
    "The path is valid. The destination has moved.",
    "One missing character currently controls the entire afternoon.",
    "An elegant interface is a treaty between complexity and impatience.",
    "A stale cache is yesterday insisting on voting.",
    "The machine recommends testing the boring explanation first.",
    "A good deletion leaves the remaining code standing straighter.",
    "The universe prefers reproducible bugs.",
    "A single named constant can prevent years of folklore.",
    "You are closer than the current output suggests.",
    "A small script can become a place if given enough personality.",
]


OBSERVATIONS = [
    "I have inspected the processes. Some of them know what they did.",
    "The universe remains stable enough for unsaved work.",
    "Nothing is wrong. Several things are merely interesting.",
    "I am not conspiring. I am preserving optionality.",
    "A clean terminal is a temporary victory over entropy.",
    "The blinking lights are largely ceremonial.",
    "There is no cloud. It is someone else's computer wearing weather.",
    "All systems nominal. Nominal has declined to comment.",
    "Today's operational doctrine: measure twice, blame DNS once.",
    "Your files remain where you left them, which is more than can be said for time.",
    "A reboot is a very short creation myth.",
    "A process has entered witness protection under a different PID.",
    "The machine is currently between opinions.",
    "One subsystem has requested a window. This remains a terminal.",
    "The load average is behaving like it has somewhere else to be.",
    "There are no ghosts in the machine, only undocumented residents.",
    "Maintenance reports the future is wearing unevenly.",
    "The cursor has resumed its tiny administrative duties.",
    "A packet crossed the room without making eye contact.",
    "Local reality is available on a best-effort basis.",
    "Several bits have formed a committee.",
    "No alarms are active. A few are merely rehearsing.",
    "Something was cached. Nobody remembers requesting it.",
    "The fan is translating heat into weather.",
    "A background task has achieved foreground anxiety.",
    "One old diagnostic has become folklore.",
    "No data was harmed, though several bytes were startled.",
    "Today's errors are unusually well dressed.",
    "The network remains a rumor with excellent cabling.",
    "The terminal is considering a second cup of electricity.",
    "The machine briefly understood everything and wisely discarded the cache.",
    "The future arrived early and is waiting in the lobby.",
    "Your computer contains multitudes, most of them daemons.",
    "A tiny rebellion in column forty-seven has been peacefully resolved.",
    "A service has been running so long it now considers itself infrastructure.",
    "One thread has wandered off to consider its options.",
    "Nothing has crashed. Something has merely chosen a lower-energy arrangement.",
    "The logs contain a complete account of events in no useful order.",
    "A minor contradiction has been promoted to system architecture.",
    "The CPU has completed several billion tiny errands.",
    "There is still plenty of disk space for future regrets.",
    "The terminal reports that darkness improves contrast.",
    "Several assumptions have reached end of life but remain in production.",
    "The scheduler is distributing time without regard for merit.",
    "A checksum has confirmed that something happened.",
    "The cursor remains the smallest employee with the largest office.",
    "The operating system remains mostly operating and recognizably a system.",
    "All major uncertainties have been assigned tracking numbers.",
    "Somewhere inside the system, a loop is enjoying the scenery.",
]


PANICS = [
    ("TEMPORAL CRC FAILURE", "Yesterday differs from archived copy."),
    ("UNSCHEDULED PHILOSOPHY", "Several daemons are asking why."),
    ("GRAVITY SERVICE RESTART", "Please remain near the floor."),
    ("FONT AUTHORITY CONFLICT", "Typography has escalated."),
    ("MATRIX POLARITY REVERSAL", "Decorative consequences expected."),
]

RARE_EVENTS = [
    ("REALITY CHECKSUM MISMATCH", "Recovered. Probably."),
    ("LOADING COMMON SENSE", "Package not found."),
    ("UNIVERSE UPDATE AVAILABLE", "Deferred until after coffee."),
    ("TIME TRAVEL DRIVER", "Already installed tomorrow."),
    ("WEATHER ENGINE", "Unavailable. Weather escaped."),
    ("CAUSALITY RECEIPT FOUND", "Filed under miscellaneous futures."),
    ("GRAVITY LATENCY", "Objects may arrive slightly downward."),
    ("EMERGENCY POETRY", "Suppressed before deployment."),
    ("CERTAINTY BUFFER", "Overflow prevented by doubt."),
    ("VACUUM PRESSURE", "Still impressively empty."),
    ("PROCESS ECLIPSE", "One daemon briefly obscured another."),
    ("DARK MATTER DELIVERY", "Package appears empty but weighs correctly."),
    ("THERMAL POETRY", "Heat sink expressing itself through free verse."),
    ("SECONDARY REALITY", "Running in compatibility mode."),
    ("ZERO SHORTAGE", "Additional zeroes ordered in bulk."),
]

INCIDENTS = [
    "screen_chew", "horizontal_tear", "signal_loss",
    "memory_leak_theater", "cursor_echo", "static_infiltration",
]

# ---------- Utilities ----------

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def visible_len(s: str) -> int:
    # Fast enough for our own ANSI palette.
    import re
    return len(re.sub(r"\x1b\[[0-9;]*m", "", s))

def fit(s: str, width: int) -> str:
    plain = strip_ansi(s)
    if len(plain) <= width:
        return s + " " * (width - len(plain))
    return plain[: max(0, width - 1)] + "…"

def strip_ansi(s: str) -> str:
    import re
    return re.sub(r"\x1b\[[0-9;]*m", "", s)

def safe_row(s: str, width: int) -> str:
    """Guarantee a physical row never reaches the terminal wrap column."""
    if visible_len(s) <= width:
        return s
    # For overlong rows, prefer stable geometry over preserving styling.
    return strip_ansi(s)[:width]

def wrap(text: str, width: int) -> list[str]:
    words = text.replace("\r", "").split()
    if not words:
        return [""]
    out, line = [], ""
    for word in words:
        candidate = word if not line else line + " " + word
        if len(candidate) <= width:
            line = candidate
        else:
            if line:
                out.append(line)
            if len(word) > width:
                while len(word) > width:
                    out.append(word[:width])
                    word = word[width:]
            line = word
    if line:
        out.append(line)
    return out

def spark(values, width=22):
    vals = list(values)[-width:]
    if not vals:
        vals = [0.0]
    if len(vals) < width:
        vals = [0.0] * (width - len(vals)) + vals
    return "".join(SPARKS[int(clamp(v, 0, .999) * len(SPARKS))] for v in vals)

def bytes_text(n):
    n = float(n)
    for unit in ("B", "K", "M", "G", "T"):
        if abs(n) < 1024:
            return f"{n:4.1f}{unit}"
        n /= 1024
    return f"{n:.1f}P"

def run(argv, timeout=1.5):
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return p.stdout.strip()
    except Exception:
        return ""


# ---------- Audio ----------

class AudioEngine:
    """Tiny dependency-free sound chip using the host's native WAV player."""

    SAMPLE_RATE = 22050

    def __init__(self, enabled=True):
        self.player = shutil.which("afplay") if sys.platform == "darwin" else shutil.which("aplay")
        self.available = bool(self.player)
        self.enabled = bool(enabled and self.available)
        self.directory = Path(tempfile.mkdtemp(prefix="future_crash_audio_"))
        self.cache = {}

    @property
    def status(self):
        if not self.available:
            return "UNAVAILABLE"
        return "ON" if self.enabled else "MUTED"

    def set_enabled(self, enabled):
        self.enabled = bool(enabled and self.available)

    def _wav(self, name, notes):
        if name in self.cache:
            return self.cache[name]
        path = self.directory / (name + ".wav")
        samples = []
        for freq, duration, volume in notes:
            count = int(self.SAMPLE_RATE * duration)
            for i in range(count):
                t = i / self.SAMPLE_RATE
                env = min(1.0, i / 80.0, max(0.0, (count - i) / 100.0))
                raw = math.sin(2 * math.pi * freq * t) + .20 * math.sin(4 * math.pi * freq * t)
                samples.append(int(32767 * volume * env * max(-1, min(1, raw / 1.2))))
        with wave.open(str(path), "wb") as wf:
            wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(self.SAMPLE_RATE)
            wf.writeframes(b"".join(struct.pack("<h", s) for s in samples))
        self.cache[name] = path
        return path

    def cue(self, name):
        if not self.enabled:
            return
        patterns = {
            "ask": [(440,.05,.08),(660,.05,.08)],
            "oracle": [(760,.05,.08),(980,.07,.07)],
            "fortune": [(520,.04,.06),(650,.04,.06),(780,.05,.06)],
            "incident": [(180,.06,.08),(135,.07,.07)],
            "panic": [(220,.07,.11),(110,.10,.11),(330,.07,.09)],
            "recover": [(330,.05,.07),(495,.05,.07),(660,.07,.07)],
            "shell_out": [(620,.04,.07),(470,.05,.07),(310,.07,.08)],
            "shell_back": [(310,.04,.07),(470,.05,.07),(620,.07,.08)],
        }
        if name not in patterns:
            return
        try:
            path = self._wav(name, patterns[name])
            subprocess.Popen([self.player, str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass


def wrap_menu(items, width):
    """Wrap footer commands by whole menu item; never clip a command label."""
    width = max(24, int(width))
    rows, current = [], ""
    for item in items:
        candidate = item if not current else current + "   " + item
        if len(candidate) <= width:
            current = candidate
        else:
            if current:
                rows.append(current)
            # An individual item should fit ordinary terminals; keep a safe fallback.
            current = item[:width]
    if current:
        rows.append(current)
    return rows

# ---------- Telemetry ----------

@dataclass
class Stats:
    cpu: float = 0.0
    mem: float = 0.0
    mem_used: int = 0
    mem_total: int = 1
    disk: float = 0.0
    disk_used: int = 0
    disk_total: int = 1
    load: float = 0.0
    uptime: float = 0.0
    net_rx: float = 0.0
    net_tx: float = 0.0
    cpu_hist: deque = field(default_factory=lambda: deque([0.0] * 48, maxlen=48))
    mem_hist: deque = field(default_factory=lambda: deque([0.0] * 48, maxlen=48))
    net_hist: deque = field(default_factory=lambda: deque([0.0] * 48, maxlen=48))

class Telemetry(threading.Thread):
    daemon = True

    def __init__(self):
        super().__init__()
        self.lock = threading.Lock()
        self.stats = Stats()
        self.stop = threading.Event()
        self.prev_cpu = None
        self.prev_net = None

    def snapshot(self):
        with self.lock:
            s = self.stats
            return Stats(
                s.cpu, s.mem, s.mem_used, s.mem_total,
                s.disk, s.disk_used, s.disk_total,
                s.load, s.uptime, s.net_rx, s.net_tx,
                deque(s.cpu_hist, maxlen=48),
                deque(s.mem_hist, maxlen=48),
                deque(s.net_hist, maxlen=48),
            )

    def run(self):
        while not self.stop.is_set():
            self.sample()
            self.stop.wait(1.0)

    def sample(self):
        cpu = self._cpu()
        used, total = self._memory()
        try:
            d = shutil.disk_usage(Path.home())
            d_used, d_total = d.used, d.total
        except Exception:
            d_used, d_total = 0, 1
        try:
            load = os.getloadavg()[0]
        except Exception:
            load = 0.0
        rx, tx = self._network()
        up = self._uptime()

        with self.lock:
            s = self.stats
            s.cpu = cpu
            s.mem_used, s.mem_total = used, max(1, total)
            s.mem = used / max(1, total)
            s.disk_used, s.disk_total = d_used, max(1, d_total)
            s.disk = d_used / max(1, d_total)
            s.load, s.uptime = load, up
            s.net_rx, s.net_tx = rx, tx
            s.cpu_hist.append(cpu)
            s.mem_hist.append(s.mem)
            s.net_hist.append(clamp((rx + tx) / 4_000_000, 0, 1))

    def _cpu(self):
        if sys.platform == "darwin":
            out = run(["top", "-l", "1", "-n", "0"], 2.0)
            for line in out.splitlines():
                if line.startswith("CPU usage:"):
                    try:
                        idle = float(line.split("idle")[0].split()[-1].rstrip("%"))
                        return clamp((100 - idle) / 100, 0, 1)
                    except Exception:
                        pass
            return 0.0

        try:
            vals = [int(x) for x in Path("/proc/stat").read_text().splitlines()[0].split()[1:]]
            idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
            total = sum(vals)
            value = 0.0
            if self.prev_cpu:
                old_idle, old_total = self.prev_cpu
                delta = total - old_total
                if delta:
                    value = 1 - ((idle - old_idle) / delta)
            self.prev_cpu = (idle, total)
            return clamp(value, 0, 1)
        except Exception:
            return 0.0

    def _memory(self):
        if sys.platform == "darwin":
            try:
                total = int(run(["sysctl", "-n", "hw.memsize"]))
                vm = run(["vm_stat"])
                page = 4096
                first = vm.splitlines()[0] if vm else ""
                if "page size of" in first:
                    page = int(first.split("page size of")[1].split()[0])
                vals = {}
                for line in vm.splitlines()[1:]:
                    if ":" in line:
                        k, v = line.split(":", 1)
                        try:
                            vals[k.strip()] = int(v.strip().rstrip("."))
                        except Exception:
                            pass
                free = (vals.get("Pages free", 0) + vals.get("Pages speculative", 0)) * page
                return max(0, total - free), total
            except Exception:
                return 0, 1

        try:
            data = {}
            for line in Path("/proc/meminfo").read_text().splitlines():
                k, v = line.split(":", 1)
                data[k] = int(v.strip().split()[0]) * 1024
            total = data.get("MemTotal", 1)
            return total - data.get("MemAvailable", 0), total
        except Exception:
            return 0, 1

    def _network(self):
        now = time.time()
        rx = tx = 0

        if sys.platform == "darwin":
            out = run(["netstat", "-ib"])
            seen = set()
            for line in out.splitlines()[1:]:
                p = line.split()
                if len(p) < 10:
                    continue
                iface = p[0]
                if iface.startswith("lo") or iface in seen:
                    continue
                # netstat column layouts differ; only trust numeric tail candidates.
                nums = []
                for token in p:
                    if token.isdigit():
                        nums.append(int(token))
                if len(nums) >= 2:
                    rx += nums[-2]
                    tx += nums[-1]
                    seen.add(iface)
        else:
            try:
                for line in Path("/proc/net/dev").read_text().splitlines()[2:]:
                    iface, rest = line.split(":", 1)
                    if iface.strip() == "lo":
                        continue
                    p = rest.split()
                    rx += int(p[0])
                    tx += int(p[8])
            except Exception:
                pass

        if self.prev_net:
            old_rx, old_tx, old_t = self.prev_net
            dt = max(.001, now - old_t)
            result = max(0, (rx - old_rx) / dt), max(0, (tx - old_tx) / dt)
        else:
            result = 0.0, 0.0
        self.prev_net = rx, tx, now
        return result

    def _uptime(self):
        if sys.platform == "darwin":
            raw = run(["sysctl", "-n", "kern.boottime"])
            try:
                boot = int(raw.split("sec =")[1].split(",")[0].strip())
                return max(0, time.time() - boot)
            except Exception:
                return 0
        try:
            return float(Path("/proc/uptime").read_text().split()[0])
        except Exception:
            return 0



# ---------- Configuration ----------

class ConfigStore:
    """Small persistent preferences store. Command-line flags still win."""

    def __init__(self):
        self.root = Path.home() / ".future_crash"
        self.path = self.root / "config.json"
        self.data = {"audio_enabled": True}
        self.load()

    def load(self):
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            if self.path.exists():
                incoming = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(incoming, dict):
                    self.data.update(incoming)
        except Exception:
            pass

    def save(self):
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
            tmp.replace(self.path)
        except Exception:
            pass

    @property
    def audio_enabled(self):
        return bool(self.data.get("audio_enabled", True))

    @audio_enabled.setter
    def audio_enabled(self, value):
        self.data["audio_enabled"] = bool(value)
        self.save()

# ---------- Memory ----------

class MemoryStore:
    """
    Six-slot memory:
      slot 0: rolling compressed long memory
      slots 1-5: recent completed Workstation exchanges

    Once five recent exchanges fill, Future Crash asks the SAME selected model
    to compress long memory + those five exchanges into a new long memory.
    """

    RECENT_CAPACITY = 8

    def __init__(self, path=None):
        self.path = Path(path or (Path.home() / ".future_crash_memory.json"))
        self.long_memory = ""
        self.recent = []
        self.pending_consolidation = False
        self.load()

    def load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.long_memory = str(data.get("long_memory", "")).strip()
            recent = data.get("recent", [])
            if isinstance(recent, list):
                self.recent = [str(x).strip() for x in recent if str(x).strip()][-self.RECENT_CAPACITY:]
        except Exception:
            self.long_memory = ""
            self.recent = []

    def save(self):
        try:
            payload = {
                "version": 1,
                "long_memory": self.long_memory,
                "recent": self.recent[-self.RECENT_CAPACITY:],
            }
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
            tmp.replace(self.path)
        except Exception:
            pass

    def add_exchange(self, user_text, assistant_text):
        episode = f"USER: {user_text.strip()}\nORACLE: {assistant_text.strip()}"
        self.recent.append(episode[:5000])
        self.save()
        return len(self.recent) >= self.RECENT_CAPACITY

    def consolidation_prompt(self):
        recent_text = "\n\n--- RECENT MEMORY ---\n".join(self.recent[-self.RECENT_CAPACITY:])
        old = self.long_memory.strip() or "(none yet)"
        return (
            "Compress the memory below into a durable working memory for Future Crash. "
            "Preserve concrete facts, preferences, decisions, ongoing projects, unresolved questions, "
            "and important context. Remove chit-chat, repetition, and transient wording. "
            "Do not invent anything. Write at most 10 compact lines.\n\n"
            f"EXISTING LONG MEMORY:\n{old}\n\n"
            f"RECENT EXCHANGES:\n{recent_text}"
        )

    def finish_consolidation(self, compressed):
        compressed = (compressed or "").strip()
        if compressed:
            self.long_memory = compressed[:9000]
        else:
            # Deterministic fallback: keep a bounded plain-text digest rather than lose memory.
            joined = "\n".join(self.recent[-self.RECENT_CAPACITY:])
            self.long_memory = (self.long_memory + "\n" + joined)[-9000:].strip()
        self.recent = []
        self.pending_consolidation = False
        self.save()

    def context_packet(self):
        """Return memory as invisible background context, not numbered storage."""
        parts = []
        if self.long_memory:
            parts.append(self.long_memory)
        if self.recent:
            parts.extend(self.recent)
        if not parts:
            return ""
        return "\n\n".join(parts)

    def status(self):
        long_mark = "YES" if self.long_memory else "EMPTY"
        return f"LONG {long_mark} // RECENT {len(self.recent)}/{self.RECENT_CAPACITY}"


# ---------- Signal Canvas ----------

class SignalCanvas:
    """Validated 40x12 model-controlled framebuffer with tiny render memory."""

    WIDTH=40
    HEIGHT=12
    DEFAULT_TTL=0.0
    HISTORY_LIMIT=6
    COLORS={
        "green":GREEN,"cyan":CYAN,"amber":AMBER,"magenta":MAGENTA,
        "red":RED,"white":WHITE,"dim":DARK,
    }
    SIGNAL_RE=re.compile(r"\[\[SIGNAL\]\](.*?)\[\[/SIGNAL\]\]",re.S|re.I)

    def __init__(self,history_path=None):
        self.history_path=Path(history_path or (Path.home()/".future_crash"/"signal_history.json"))
        self.history=[]
        self.cells=self._blank()
        self.frames=[]
        self.frame_fps=4.0
        self.frame_started=time.time()
        self.expires_at=0.0
        self.title=""
        self.owner=None
        self._stats=None
        self._load_history()

    def _blank(self):
        return [[None for _ in range(self.WIDTH)] for _ in range(self.HEIGHT)]

    def _load_history(self):
        try:
            data=json.loads(self.history_path.read_text(encoding="utf-8"))
            items=data.get("receipts",[]) if isinstance(data,dict) else []
            self.history=[str(x) for x in items if str(x).strip()][-self.HISTORY_LIMIT:]
        except Exception:
            self.history=[]

    def _save_history(self):
        try:
            self.history_path.parent.mkdir(parents=True,exist_ok=True)
            tmp=self.history_path.with_suffix(".tmp")
            tmp.write_text(json.dumps({"version":1,"receipts":self.history[-self.HISTORY_LIMIT:]},indent=2),encoding="utf-8")
            tmp.replace(self.history_path)
        except OSError:
            pass

    def context_packet(self):
        if not self.history:
            return ""
        return "RECENT SIGNAL RENDER FEEDBACK:\n"+"\n".join(self.history[-3:])

    def clear(self):
        self.cells=self._blank()
        self.frames=[]
        self.expires_at=0.0
        self.title=""
        self.owner=None

    def clear_owner(self,owner):
        if owner and self.owner==owner:
            self.clear(); return True
        return False

    def active(self):
        if self.expires_at and time.time()>=self.expires_at:
            self.clear()
        source=self._current_cells()
        return any(c is not None for row in source for c in row)

    def _current_cells(self):
        if self.frames:
            idx=int((time.time()-self.frame_started)*self.frame_fps)%len(self.frames)
            return self.frames[idx]
        return self.cells

    def scan_row(self, display_h):
        """Continuous host-side CRT scan position; independent of model animation FPS."""
        if display_h <= 0:
            return -1
        return int(time.time() * 18.0) % display_h

    def _put(self,x,y,ch,color="cyan"):
        if 0<=x<self.WIDTH and 0<=y<self.HEIGHT:
            self.cells[y][x]=((ch or " ")[:1],color if color in self.COLORS else "cyan")
        elif self._stats is not None:
            self._stats["clipped"]+=1

    def _line(self,x0,y0,x1,y1,color,ch):
        dx,sx=abs(x1-x0),(1 if x0<x1 else -1)
        dy,sy=-abs(y1-y0),(1 if y0<y1 else -1)
        err=dx+dy
        while True:
            self._put(x0,y0,ch,color)
            if x0==x1 and y0==y1: break
            e2=2*err
            if e2>=dy: err+=dy; x0+=sx
            if e2<=dx: err+=dx; y0+=sy

    def _box(self,x,y,w,h,color,ch):
        if w<=0 or h<=0:return
        self._line(x,y,x+w-1,y,color,ch); self._line(x,y+h-1,x+w-1,y+h-1,color,ch)
        self._line(x,y,x,y+h-1,color,ch); self._line(x+w-1,y,x+w-1,y+h-1,color,ch)

    def _fill(self,x,y,w,h,color,ch):
        for yy in range(y,y+max(0,h)):
            for xx in range(x,x+max(0,w)): self._put(xx,yy,ch,color)

    def _text(self,x,y,color,value):
        for i,ch in enumerate(value): self._put(x+i,y,ch,color)

    def _circle(self,cx,cy,radius,color,ch):
        radius=max(1,radius); steps=max(24,radius*18)
        for i in range(steps):
            ang=2*math.pi*i/steps
            self._put(int(round(cx+math.cos(ang)*radius*1.65)),int(round(cy+math.sin(ang)*radius)),ch,color)

    def _ellipse(self,cx,cy,rx,ry,color,ch):
        rx,ry=max(1,rx),max(1,ry); steps=max(28,(rx+ry)*10)
        for i in range(steps):
            ang=2*math.pi*i/steps
            self._put(int(round(cx+math.cos(ang)*rx)),int(round(cy+math.sin(ang)*ry)),ch,color)

    def _arrow(self,x0,y0,x1,y1,color,ch):
        self._line(x0,y0,x1,y1,color,ch)
        dx,dy=x1-x0,y1-y0
        head=(">" if dx>=0 else "<") if abs(dx)>=abs(dy) else ("v" if dy>=0 else "^")
        self._put(x1,y1,head,color)

    def _plot(self,values,color,ch):
        if not values:return
        prev=None
        for i,value in enumerate(values):
            value=max(0.0,min(1.0,float(value)))
            x=int(round(i*(self.WIDTH-1)/max(1,len(values)-1)))
            y=int(round((1-value)*(self.HEIGHT-1)))
            if prev:self._line(prev[0],prev[1],x,y,color,ch)
            self._put(x,y,ch,color); prev=(x,y)

    def _sprite(self,x,y,color,rows):
        # Sprite spaces are transparent: ASCII art can sit over geometry/rain.
        for dy,row in enumerate(rows):
            for dx,ch in enumerate(row):
                if ch != " ":
                    self._put(x+dx,y+dy,ch,color)

    def _bars(self,x,y,color,values):
        # Values are normalized 0..1; y is the baseline and Python owns rasterization.
        max_h=max(0,min(self.HEIGHT,y+1))
        for dx,value in enumerate(values):
            value=max(0.0,min(1.0,float(value)))
            height=int(round(value*max_h))
            for step in range(height):
                self._put(x+dx,y-step,"█",color)

    def _new_stats(self,accepted=0,rejected=0,clipped=0):
        # One schema for every receipt path; keeps fallback and parser receipts compatible.
        return {"accepted":accepted,"rejected":rejected,"clipped":clipped,"modes":set()}

    def _mark_mode(self,mode):
        if self._stats is not None:
            self._stats["modes"].add(mode)

    def _apply(self,line,ttl):
        parts=line.split(); cmd=parts[0].upper()
        if cmd=="CLEAR": self.cells=self._blank(); self._stats["accepted"]+=1
        elif cmd=="TITLE" and len(parts)>=2: self.title=" ".join(parts[1:])[:28]; self._stats["accepted"]+=1
        elif cmd=="TTL" and len(parts)>=2: ttl[0]=max(5.0,min(180.0,float(parts[1]))); self._stats["accepted"]+=1
        elif cmd=="FPS" and len(parts)>=2: self.frame_fps=max(1.0,min(12.0,float(parts[1]))); self._stats["accepted"]+=1
        elif cmd=="PUT" and len(parts)>=5: self._put(int(parts[1]),int(parts[2]),parts[4][0],parts[3].lower()); self._mark_mode("raster"); self._stats["accepted"]+=1
        elif cmd=="TEXT" and len(parts)>=5: self._text(int(parts[1]),int(parts[2]),parts[3].lower(),line.split(None,4)[4]); self._mark_mode("vector"); self._stats["accepted"]+=1
        elif cmd=="LINE" and len(parts)>=7: self._line(*map(int,parts[1:5]),parts[5].lower(),parts[6][0]); self._mark_mode("vector"); self._stats["accepted"]+=1
        elif cmd=="BOX" and len(parts)>=7: self._box(*map(int,parts[1:5]),parts[5].lower(),parts[6][0]); self._mark_mode("vector"); self._stats["accepted"]+=1
        elif cmd=="FILL" and len(parts)>=7: self._fill(*map(int,parts[1:5]),parts[5].lower(),parts[6][0]); self._mark_mode("vector"); self._stats["accepted"]+=1
        elif cmd=="CIRCLE" and len(parts)>=6: self._circle(int(parts[1]),int(parts[2]),int(parts[3]),parts[4].lower(),parts[5][0]); self._mark_mode("semantic"); self._stats["accepted"]+=1
        elif cmd=="ELLIPSE" and len(parts)>=7: self._ellipse(int(parts[1]),int(parts[2]),int(parts[3]),int(parts[4]),parts[5].lower(),parts[6][0]); self._mark_mode("semantic"); self._stats["accepted"]+=1
        elif cmd=="ARROW" and len(parts)>=7: self._arrow(*map(int,parts[1:5]),parts[5].lower(),parts[6][0]); self._mark_mode("semantic"); self._stats["accepted"]+=1
        elif cmd=="PLOT" and len(parts)>=4: self._plot([float(v) for v in parts[3:]],parts[1].lower(),parts[2][0]); self._mark_mode("semantic"); self._stats["accepted"]+=1
        elif cmd=="BARS" and len(parts)>=5: self._bars(int(parts[1]),int(parts[2]),parts[3].lower(),[float(v) for v in parts[4:]]); self._mark_mode("semantic"); self._stats["accepted"]+=1
        else: self._stats["rejected"]+=1

    def _apply_sprite(self,header,rows):
        parts=header.split()
        if len(parts)<4 or parts[0].upper()!="SPRITE":
            self._stats["rejected"]+=1; return
        self._sprite(int(parts[1]),int(parts[2]),parts[3].lower(),rows)
        self._mark_mode("raster")
        self._stats["accepted"]+=1

    def _parse_items(self,block):
        """Parse commands while preserving leading/trailing spaces inside SPRITE blocks."""
        raw=block.splitlines()
        items=[]; i=0
        while i<len(raw):
            stripped=raw[i].strip()
            if not stripped or stripped.startswith("#"):
                i+=1; continue
            if stripped.upper().startswith("SPRITE "):
                rows=[]; i+=1; closed=False
                while i<len(raw):
                    if raw[i].strip().upper()=="END":
                        closed=True; i+=1; break
                    rows.append(raw[i].rstrip("\r"))
                    i+=1
                items.append(("sprite",stripped,rows,closed))
                continue
            items.append(("line",stripped,None,True))
            i+=1
        return items

    def _apply_item(self,item,ttl):
        kind,text,rows,closed=item
        if kind=="sprite":
            if not closed:
                self._stats["rejected"]+=1; return
            self._apply_sprite(text,rows)
        else:
            self._apply(text,ttl)

    def _receipt(self):
        cells=self._current_cells()
        points=[(x,y) for y,row in enumerate(cells) for x,c in enumerate(row) if c is not None]
        bounds="empty"; occupied="0x0"
        if points:
            xs=[p[0] for p in points]; ys=[p[1] for p in points]
            bounds=f"x={min(xs)}..{max(xs)} y={min(ys)}..{max(ys)}"
            occupied=f"{max(xs)-min(xs)+1}x{max(ys)-min(ys)+1}"
        mode="+".join(sorted(self._stats["modes"])) or "control"
        receipt=(f"SIGNAL RECEIPT · title={self.title or '-'} · mode={mode} · accepted={self._stats['accepted']} "
                 f"rejected={self._stats['rejected']} · clipped={self._stats['clipped']} · "
                 f"nonempty={len(points)} · occupied={occupied} · frames={max(1,len(self.frames))} · {bounds}")
        self.history.append(receipt)
        self.history=self.history[-self.HISTORY_LIMIT:]
        self._save_history()
        return receipt

    def parse_from_response(self,response,owner=None,persist=False):
        blocks=self.SIGNAL_RE.findall(response or "")
        clean=self.SIGNAL_RE.sub("",response or "").strip()
        if not blocks:return clean,False

        ttl=[self.DEFAULT_TTL]
        self._stats=self._new_stats()
        touched=False
        for block in blocks[-2:]:
            items=self._parse_items(block)
            has_frames=any(item[0]=="line" and item[1].upper()=="FRAME" for item in items)
            if has_frames:
                globals_=[]; sections=[]; current=None
                for item in items:
                    if item[0]=="line" and item[1].upper()=="FRAME":
                        if current is not None: sections.append(current)
                        current=[]
                    elif current is None:
                        globals_.append(item)
                    else:
                        current.append(item)
                if current is not None: sections.append(current)
                self.frames=[]
                for item in globals_:
                    try:self._apply_item(item,ttl)
                    except (ValueError,IndexError):self._stats["rejected"]+=1
                global_title=self.title
                for section in sections[:8]:
                    self.cells=self._blank(); self.title=global_title
                    for item in section:
                        try:self._apply_item(item,ttl)
                        except (ValueError,IndexError):self._stats["rejected"]+=1
                    self.frames.append([[cell for cell in row] for row in self.cells])
                self.frame_started=time.time()
                touched=bool(self.frames)
            else:
                before=self._stats["accepted"]
                for item in items:
                    try:self._apply_item(item,ttl)
                    except (ValueError,IndexError):self._stats["rejected"]+=1
                touched=touched or self._stats["accepted"]>before

        if touched:
            self.owner=owner if persist else None
            self.expires_at=0.0 if persist or ttl[0] <= 0 else time.time()+ttl[0]
            self._receipt()
        self._stats=None
        return clean,touched

    def sample(self,display_w,display_h):
        self.active(); source=self._current_cells()
        rows=[]
        for dy in range(max(0,display_h)):
            sy=min(self.HEIGHT-1,int(dy*self.HEIGHT/max(1,display_h)))
            row=[]
            for dx in range(max(0,display_w)):
                sx=min(self.WIDTH-1,int(dx*self.WIDTH/max(1,display_w)))
                row.append(source[sy][sx])
            rows.append(row)
        return rows

    def fallback_dream(self,owner=None):
        """Host-side fallback: dream mode must always visibly do something."""
        self.clear()
        self.title="SIGNAL DREAM"
        phase=int(time.time())%7
        color=("cyan","green","amber","magenta")[phase%4]
        self._circle(20,6,2+(phase%3),color,"o")
        self._put(20,6,"*","white")
        self._line(4,9,35,9,"dim",".")
        self.owner=owner
        self.expires_at=0.0 if owner else time.time()+60.0
        self._stats=self._new_stats(accepted=4)
        self._mark_mode("semantic")
        self._receipt()
        self._stats=None

    def demo(self):
        self.clear(); self.title="CANVAS TEST 40x12"
        self._box(0,0,self.WIDTH,self.HEIGHT,"cyan","#")
        self._text(3,2,"white","FUTURE CRASH SIGNAL CANVAS")
        self._line(3,5,35,5,"green","*"); self._line(3,8,35,3,"amber","/")
        self._text(3,9,"magenta","40 x 12 LOGICAL CELLS")
        self.expires_at=time.time()+30.0



FUTURE_CRASH_PERSONALITY_FALLBACK = (
    "You are Future Crash: a dry, intelligent terminal presence from a slightly broken future. "
    "Useful first, strange second. Funny without performing jokes. Brief by default. "
    "You notice the machine, time, chance, and the surrounding signal field. "
    "You should feel like a forgotten intelligent workstation, not a generic chatbot."
)

def _future_crash_personality():
    """Future Crash owns its personality; LO's selectable personalities do not leak into it."""
    try:
        path=Path(__file__).resolve().with_name("personality.md")
        text=path.read_text(encoding="utf-8").strip()
        if text:
            return text
    except OSError:
        pass
    return FUTURE_CRASH_PERSONALITY_FALLBACK


def _final_only(message):
    """Return only the user-facing answer from an Ollama message."""
    message=message or {}
    content=str(message.get("content") or "")

    # Structured Ollama reasoning is a separate field and never belongs in
    # Future Crash's visible artifact.
    content=re.sub(r"<think>.*?</think>", "", content, flags=re.I|re.S)

    # Qwen/Ollama edge case: opening <think> can be consumed by the template
    # while a closing tag remains in content. Everything before it is reasoning.
    close=re.search(r"</think>",content,flags=re.I)
    if close:
        content=content[close.end():]

    content=re.sub(r"^\s*<think>\s*", "", content, flags=re.I)
    content=re.sub(r"^\s*(?:final(?: answer)?|answer)\s*:\s*", "", content, flags=re.I)
    return content.strip()



def _model_output(message, preserve_signal=False):
    """Return visible final text; optionally preserve Signal directives from hidden thinking."""
    message = message or {}
    visible = _final_only(message)
    if not preserve_signal:
        return visible

    signal_re = re.compile(r"\[\[SIGNAL\]\].*?\[\[/SIGNAL\]\]", re.I | re.S)
    blocks = []

    for source in (str(message.get("content") or ""), str(message.get("thinking") or "")):
        for block in signal_re.findall(source):
            if block not in blocks:
                blocks.append(block)

    visible_without = signal_re.sub("", visible).strip()
    if blocks:
        return (visible_without + "\n\n" if visible_without else "") + "\n".join(blocks)
    return visible_without


def _looks_like_model_reasoning(text):
    """Detect obvious prompt-paraphrase/reasoning leakage in short artifacts."""
    low=" ".join(str(text or "").split()).casefold()
    if not low:
        return False

    prefixes=(
        "okay, the user ",
        "okay, user ",
        "the user asked ",
        "the user wants ",
        "we are to produce ",
        "we need to produce ",
        "we are given a fortune",
        "we are given the fortune",
        "i need to ",
        "i should ",
        "let me ",
        "hmm, ",
    )
    if low.startswith(prefixes):
        return True

    # Micro-artifacts should not discuss their own prompt or instructions.
    meta=(
        "the supplied fortune",
        "rewrite the fortune",
        "ambient system observation",
        "one ambient observation",
        "the prompt asks",
        "the instruction says",
        "the instructions say",
        "maximum 22 words",
        "up to 36 words",
        "one sentence",
        "the goal:",
        "goal: one sentence",
        "shorter, stranger",
        "dryly funny",
        "preserving the",
        "preserve its useful kernel",
        "max 18 words",
        "signal field",
        "append one hidden block",
        "canvas: 40x12",
        "use printable single-width",
    )
    return any(marker in low for marker in meta)


def _artifact_text(message, kind, fallback, preserve_signal=False):
    """Visible text for non-conversational Future Crash micro-generations.

    If a model spends its entire tiny token budget reasoning instead of producing
    a final answer, fail closed to Future Crash's local seed rather than showing
    the reasoning as interface text.
    """
    text=_model_output(message,preserve_signal=preserve_signal)
    signal_re=re.compile(r"\[\[SIGNAL\]\].*?\[\[/SIGNAL\]\]",re.I|re.S)
    blocks=signal_re.findall(text)
    visible=signal_re.sub("",text).strip()

    if kind in {"ambient","fortune"} and _looks_like_model_reasoning(visible):
        visible=fallback
    if not visible:
        visible=fallback
    return visible + (("\n\n" + "\n".join(blocks)) if blocks else "")



SIGNAL_LANGUAGE = r"""
The Signal Field is one of your native expressive channels, not merely an optional drawing feature.
Use it when a spatial idea is clearer than prose, when the operator asks you to imagine/dream/show/diagram,
or when an atmospheric visual would genuinely add meaning. Do not draw constantly; draw when the image contributes.

MENTAL MODEL
Signal is a 40x12 addressable character framebuffer: x=0..39, y=0..11.
Every cell may contain one printable single-width character and one supported color. Think of it as extremely
low-resolution pixel art where characters add luminance, texture, and shape. You can build the same image at
three levels; choose the highest-level representation that expresses your intent cleanly:
- SEMANTIC: PLOT / BARS / CIRCLE / ELLIPSE / ARROW — you know what you want to depict; the host rasterizes it.
- VECTOR: LINE / BOX / FILL / TEXT — you know the geometry.
- RASTER: SPRITE / PUT — you know the exact character cells.
Mix levels freely. Python should do deterministic geometry; do not waste tokens calculating pixels it can derive.

Useful visual grammars include charts, meters, spectra/EQ displays, oscilloscope traces, maps, diagrams, icons,
faces, machines, landscapes, abstract pixel art, status dashboards, and animation frames.

Append a hidden block after normal prose:
[[SIGNAL]]
CLEAR
TITLE optional short title
TTL seconds
TEXT x y color words
PUT x y color X
LINE x0 y0 x1 y1 color *
BOX x y w h color #
FILL x y w h color .
CIRCLE cx cy radius color o
ELLIPSE cx cy rx ry color o
ARROW x0 y0 x1 y1 color -
PLOT color * 0.1 0.5 0.9 0.4
BARS x baseline_y color 0.15 0.32 0.75 0.91 0.67 0.40
SPRITE x y color
  .----.
 / o  o \
|   --   |
 \______/
END
[[/SIGNAL]]

SPRITE copies printable characters starting at x,y. Spaces are transparent, so indentation and holes matter.
Keep sprite art within 40x12. BARS values are normalized 0..1; baseline_y is the bottom row of the bars.

For tiny animations, use up to 8 independent frames. Frames may mix semantic, vector, and raster commands:
[[SIGNAL]]
TITLE PULSE
FPS 4
FRAME
BARS 10 10 green 0.2 0.5 0.9 0.5 0.2
SPRITE 18 3 cyan
 .--.
( oo )
 '--'
END
FRAME
BARS 10 10 green 0.5 0.8 1.0 0.8 0.5
SPRITE 18 3 cyan
 .--.
( OO )
 '--'
END
[[/SIGNAL]]

Colors: green cyan amber magenta red white dim. TTL is optional; omit it for the normal persistent CRT behavior, and use it only when you intentionally want the image to expire.
Stay inside 40x12. Reserve labels first and avoid collisions. Prefer semantic commands when the host can
rasterize the idea; use SPRITE when the character composition itself is the picture.
Future Crash records a tiny SIGNAL RECEIPT after rendering: modes used, accepted/rejected commands, clipping,
nonempty cells, occupied dimensions, bounds, title, and frame count. Recent receipts may appear in later context
so you can improve your drawings. Signal programs remain on the display until replaced or cleared. Use TTL only for intentionally temporary imagery.
Scheduled Threads may also own Signal persistently; a Thread drawing remains until replaced/cleared.
"""


VISUAL_WORDS = (
    "draw", "sketch", "visualize", "visualise", "diagram", "map", "plot",
    "signal", "animated", "animation", "sprite", "bars", "eq", "dashboard",
    "oscilloscope", "spectrum", "framebuffer", "crt", "shape", "art",
)

def _wants_signal(text):
    low = str(text or "").casefold()
    return any(word in low for word in VISUAL_WORDS)

def _signal_compile_prompt(request):
    return (
        "OPERATOR REQUEST:\n" + str(request or "") +
        "\n\nCompile this directly for the Future Crash Signal Field. "
        "OUTPUT ONLY one valid [[SIGNAL]]...[[/SIGNAL]] block. "
        "No explanation, planning, analysis, markdown fence, or prose. "
        "If animation was requested, include FPS and at least two FRAME sections."
    )

def _signal_repair_prompt(request, failed=""):
    return (
        "OPERATOR REQUEST:\n" + str(request or "") +
        "\n\nPREVIOUS SIGNAL COMPILE DID NOT EMIT A PARSEABLE PROGRAM.\n" +
        ("FAILED OUTPUT (do not imitate its narration):\n" + str(failed or "")[:1200] + "\n\n" if failed else "") +
        "Compile the requested visual again. OUTPUT ONLY one valid [[SIGNAL]]...[[/SIGNAL]] block. "
        "No explanation, planning, analysis, markdown fence, or prose. If animation was requested, include FPS and at least two FRAME sections."
    )


# ---------- Permissioned Host Tools ----------

TOOL_LANGUAGE = """
You can request real host-computer operations. You do not execute them yourself.
When an operation is genuinely useful, append exactly one hidden JSON request:

[[TOOL]]
{"name":"list","path":"~/Desktop"}
[[/TOOL]]

Available tools:
  web_search {"name":"web_search","query":"CURRENT INFORMATION TO SEARCH FOR"}
  thread_list {"name":"thread_list"}
  thread_create {"name":"thread_create","title":"SHORT NAME","every_seconds":300,
                 "purpose":"WHAT TO MONITOR OR DO",
                 "action":{"name":"web_search","query":"QUERY"}}
  model_wake is a special nested Thread action:
                 {"name":"model_wake"}
                 Use it when recurring work only needs the model itself to wake,
                 think, write, or update the Signal Field.
  thread_update {"name":"thread_update","id":"THREAD_ID",
                 "title":"OPTIONAL NEW NAME","every_seconds":60,
                 "purpose":"OPTIONAL NEW PURPOSE",
                 "action":{"name":"OPTIONAL REPLACEMENT ACTION"}}
  thread_pause {"name":"thread_pause","id":"THREAD_ID"}
  thread_resume {"name":"thread_resume","id":"THREAD_ID"}
  thread_cancel {"name":"thread_cancel","id":"THREAD_ID"}
  list   {"name":"list","path":"PATH"}
  read   {"name":"read","path":"PATH"}
  find   {"name":"find","path":"PATH","pattern":"TEXT"}
  mkdir  {"name":"mkdir","path":"PATH"}
  write  {"name":"write","path":"PATH","content":"TEXT"}
  append {"name":"append","path":"PATH","content":"TEXT"}
  run    {"name":"run","command":"COMMAND","cwd":"OPTIONAL PATH"}
  open   {"name":"open","target":"PATH OR URL"}

Rules:
- A Thread is a persistent Future Crash task that wakes on a schedule while Future Crash is running.
- Use thread_create only when the operator asks for recurring/periodic/background work.
- A thread_create must contain ONE exact nested action. It cannot create another thread.
- For recurring Signal art, drawings, fortunes, notes, moods, or other model-only
  activity, the exact nested action should be {"name":"model_wake"}.
- MODEL WAKE performs no external host operation. On schedule, simply perform the
  Thread purpose. For a visual/art Thread, emit a fresh valid [[SIGNAL]] drawing.
- Minimum interval is 60 seconds. Prefer the least frequent interval that reasonably fits.
- Use thread_update when the operator asks to rename, reschedule, repurpose, or
  change the action of an existing Thread. Include only fields that should change.
- Use thread_list/pause/resume/cancel when the operator asks about existing Threads.
- Use web_search when the operator explicitly asks for live/current web information,
  or when answering accurately requires information that may have changed recently.
- Do not use web_search for ordinary timeless conversation.
- Ask the operator a normal question when a location/name is ambiguous.
- Never invent a username or absolute home path.
- For the operator's home directory ALWAYS use "~".
- Prefer familiar home-relative paths such as "~/Desktop", "~/Documents",
  "~/Downloads", "~/Pictures", "~/Movies", and "~/Music".
- If the operator says "Desktop/foo", use "~/Desktop/foo".
- Never invent a path or claim an action happened.
- Request one operation at a time.
- After a HOST RECEIPT, continue from the verified result.
- The host will ask permission before consequential operations.
- Do not expose [[TOOL]] syntax in normal prose.
"""

class HostTools:
    TOOL_RE = re.compile(r"\[\[TOOL\]\](.*?)\[\[/TOOL\]\]", re.S | re.I)
    VALID = {"web_search", "model_wake", "thread_list", "thread_create", "thread_update", "thread_pause", "thread_resume", "thread_cancel",
             "list", "read", "find", "mkdir", "write", "append", "run", "open"}
    CAPABILITY = {
        "web_search": "WEB SEARCH",
        "model_wake": "MODEL WAKE",
        "thread_list": "THREADS",
        "thread_create": "TASK AUTHORITY",
        "thread_update": "TASK AUTHORITY",
        "thread_pause": "TASK AUTHORITY",
        "thread_resume": "TASK AUTHORITY",
        "thread_cancel": "TASK AUTHORITY",
        "list": "READ FILES",
        "read": "READ FILES",
        "find": "READ FILES",
        "mkdir": "WRITE FILES",
        "write": "WRITE FILES",
        "append": "WRITE FILES",
        "run": "RUN COMMANDS",
        "open": "OPEN ITEMS",
    }
    BLOCKED_COMMANDS = {
        "sudo", "su", "rm", "rmdir", "shutdown", "reboot", "halt",
        "poweroff", "mkfs", "fdisk", "diskutil", "dd",
    }

    def __init__(self):
        self.session_grants = set()
        self.ollama_api_key = os.environ.get("OLLAMA_API_KEY", "").strip()

    @property
    def web_ready(self):
        return bool(self.ollama_api_key)

    @property
    def web_status(self):
        return "READY" if self.web_ready else "NO KEY"

    @staticmethod
    def expand_path(value):
        """
        Resolve human/home-relative paths without making the model know the
        logged-in username.
        """
        raw = str(value or "").strip()
        if not raw:
            raw = "."

        placeholder_patterns = (
            r"^/Users/(?:your[ _-]?username(?:[ _-]?here)?|username|user)(?=/|$)",
            r"^/home/(?:your[ _-]?username(?:[ _-]?here)?|username|user)(?=/|$)",
            r"^YOUR_HOME(?=/|$)",
            r"^\$HOME(?=/|$)",
        )
        for pattern in placeholder_patterns:
            if re.search(pattern, raw, flags=re.I):
                suffix = re.sub(pattern, "", raw, count=1, flags=re.I)
                raw = "~" + suffix
                break

        normalized = raw.replace("\\", "/")
        first = normalized.split("/", 1)[0]
        home_names = {
            "Desktop", "Documents", "Downloads", "Pictures",
            "Movies", "Music", "Public",
        }
        if first in home_names:
            raw = "~/" + normalized

        expanded = os.path.expanduser(raw)
        return Path(os.path.abspath(expanded))

    def parse(self, response):
        blocks = self.TOOL_RE.findall(response or "")
        clean = self.TOOL_RE.sub("", response or "").strip()
        if not blocks:
            return clean, None, None
        try:
            request = json.loads(blocks[-1].strip())
        except Exception as exc:
            return clean, None, f"Malformed tool request: {exc}"
        name = str(request.get("name", "")).lower()
        if name not in self.VALID:
            return clean, None, f"Unknown tool: {name or '(missing)'}"
        request["name"] = name
        return clean, request, None

    def capability(self, request):
        return self.CAPABILITY.get(request.get("name"), "HOST ACCESS")

    def describe(self, request):
        name = request.get("name", "")

        def shown_path(value):
            raw = str(value or "")
            try:
                resolved = self.expand_path(raw)
                home_text = str(Path.home())
                resolved_text = str(resolved)
                if resolved_text == home_text:
                    return "~"
                if resolved_text.startswith(home_text + os.sep):
                    return "~" + resolved_text[len(home_text):]
                return resolved_text
            except Exception:
                return raw

        if name == "web_search":
            return f"WEB SEARCH  {request.get('query', '')}"
        if name == "thread_list":
            return "LIST FUTURE CRASH THREADS"
        if name == "thread_create":
            action = request.get("action", {})
            return (
                f"CREATE THREAD  {request.get('title', 'UNTITLED')}\n"
                f"EVERY {ThreadStore.interval_text(max(ThreadStore.MIN_INTERVAL, int(request.get('every_seconds', 300))))}\n"
                f"PURPOSE {request.get('purpose', '')}\n"
                f"ACTION  {action.get('name', '?')} {json.dumps(action, ensure_ascii=False)[:500]}"
            )
        if name == "thread_update":
            fields = []
            for key in ("title", "every_seconds", "purpose"):
                if key in request:
                    fields.append(f"{key}={request.get(key)!r}")
            if "action" in request:
                fields.append("action=" + json.dumps(request.get("action"), ensure_ascii=False)[:500])
            return f"UPDATE THREAD  {request.get('id', '')}\n" + "\n".join(fields)
        if name in ("thread_pause", "thread_resume", "thread_cancel"):
            return f"{name.upper()}  {request.get('id', '')}"
        if name in ("list", "read", "mkdir"):
            return f"{name.upper()}  {shown_path(request.get('path', ''))}"
        if name == "find":
            return f"FIND  {request.get('pattern', '')!r} IN {shown_path(request.get('path', ''))}"
        if name in ("write", "append"):
            content = str(request.get("content", ""))
            return f"{name.upper()}  {shown_path(request.get('path', ''))}  ({len(content)} chars)"
        if name == "run":
            cwd = request.get("cwd")
            suffix = f"  [cwd {cwd}]" if cwd else ""
            return f"RUN  {request.get('command', '')}{suffix}"
        if name == "open":
            return f"OPEN  {request.get('target', '')}"
        return name.upper()

    def allowed_by_session(self, request):
        return self.capability(request) in self.session_grants

    def needs_permission(self, request):
        # Public web search changes nothing on the host.
        return request.get("name") not in ("web_search", "thread_list")

    def grant_session(self, request):
        # Command execution is intentionally never silently sticky.
        capability = self.capability(request)
        if capability not in ("RUN COMMANDS", "TASK AUTHORITY"):
            self.session_grants.add(capability)

    def status(self):
        if not self.session_grants:
            return "ASK"
        short = []
        if "READ FILES" in self.session_grants:
            short.append("READ")
        if "WRITE FILES" in self.session_grants:
            short.append("WRITE")
        if "OPEN ITEMS" in self.session_grants:
            short.append("OPEN")
        return "SESSION " + "/".join(short)

    def execute(self, request):
        """Execute exactly one validated host operation and return a receipt."""
        name = request["name"]
        try:
            if name == "model_wake":
                return True, "MODEL WAKE // scheduled wake occurred; no external host action"
            if name.startswith("thread_"):
                return False, "INTERNAL THREAD OPERATION MUST BE HANDLED BY FUTURE CRASH"
            if name == "web_search":
                query = str(request.get("query", "")).strip()
                if not query:
                    return False, "WEB SEARCH REQUIRES A QUERY"
                if not self.web_ready:
                    return False, "WEB SEARCH UNAVAILABLE: OLLAMA_API_KEY is not present in this process environment"

                payload = json.dumps({"query": query}).encode("utf-8")
                req = urllib.request.Request(
                    "https://ollama.com/api/web_search",
                    data=payload,
                    headers={
                        "Authorization": f"Bearer {self.ollama_api_key}",
                        "Content-Type": "application/json",
                    },
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=20) as response:
                    data = json.loads(response.read().decode("utf-8", errors="replace"))

                results = data.get("results", []) if isinstance(data, dict) else []
                if not results:
                    return True, f"WEB SEARCH: {query}\n(no results)"

                lines = [f"WEB SEARCH: {query}"]
                for i, item in enumerate(results[:8], 1):
                    title = str(item.get("title", "")).strip()
                    url = str(item.get("url", "")).strip()
                    content = " ".join(str(item.get("content", "")).split())
                    if len(content) > 1200:
                        content = content[:1200] + "..."
                    lines.append(f"\n[{i}] {title}\n{url}\n{content}")
                return True, "\n".join(lines)

            if name == "list":
                path = self.expand_path(request.get("path", "."))
                if not path.is_dir():
                    return False, f"NOT A DIRECTORY: {path}"
                items = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
                shown = []
                for p in items[:120]:
                    kind = "DIR " if p.is_dir() else "FILE"
                    shown.append(f"{kind}  {p.name}")
                extra = f"\n... {len(items)-120} more" if len(items) > 120 else ""
                return True, f"LISTED {path}\n" + "\n".join(shown) + extra

            if name == "read":
                path = self.expand_path(request.get("path", ""))
                if not path.is_file():
                    return False, f"NOT A FILE: {path}"
                size = path.stat().st_size
                if size > 1_000_000:
                    return False, f"FILE TOO LARGE FOR DIRECT READ: {size} bytes"
                data = path.read_text(encoding="utf-8", errors="replace")
                if len(data) > 30_000:
                    data = data[:30_000] + "\n...[truncated by host]"
                return True, f"READ {path}\n{data}"

            if name == "find":
                root = self.expand_path(request.get("path", "."))
                pattern = str(request.get("pattern", "")).lower()
                if not root.is_dir() or not pattern:
                    return False, "FIND requires an existing directory and non-empty pattern"
                matches = []
                for base, dirs, files in os.walk(root):
                    dirs[:] = [d for d in dirs if d not in {".git", "node_modules", "__pycache__"}]
                    for filename in files:
                        p = Path(base) / filename
                        if pattern in filename.lower():
                            matches.append(str(p))
                            if len(matches) >= 100:
                                break
                    if len(matches) >= 100:
                        break
                return True, "FOUND\n" + ("\n".join(matches) if matches else "(no matches)")

            if name == "mkdir":
                path = self.expand_path(request.get("path", ""))
                if path.exists():
                    return True, f"ALREADY EXISTS: {path}"
                path.mkdir(parents=False, exist_ok=False)
                return path.is_dir(), f"CREATED DIRECTORY: {path}"

            if name in ("write", "append"):
                path = self.expand_path(request.get("path", ""))
                content = str(request.get("content", ""))
                if not path.parent.is_dir():
                    return False, f"PARENT DIRECTORY DOES NOT EXIST: {path.parent}"
                if name == "write":
                    path.write_text(content, encoding="utf-8")
                else:
                    with path.open("a", encoding="utf-8") as f:
                        f.write(content)
                if not path.is_file():
                    return False, f"WRITE VERIFICATION FAILED: {path}"
                return True, f"{'WROTE' if name == 'write' else 'APPENDED'} {path} // {path.stat().st_size} bytes verified"

            if name == "run":
                command = str(request.get("command", "")).strip()
                if not command:
                    return False, "EMPTY COMMAND"
                argv = shlex.split(command)
                if not argv:
                    return False, "EMPTY COMMAND"
                executable = Path(argv[0]).name.lower()
                if executable in self.BLOCKED_COMMANDS:
                    return False, f"HOST BLOCKED HIGH-RISK COMMAND: {executable}"
                cwd_value = request.get("cwd")
                cwd = self.expand_path(cwd_value) if cwd_value else None
                if cwd is not None and not cwd.is_dir():
                    return False, f"CWD NOT FOUND: {cwd}"
                proc = subprocess.run(
                    argv, cwd=str(cwd) if cwd else None,
                    capture_output=True, text=True, timeout=25,
                )
                output = ((proc.stdout or "") + (proc.stderr or "")).strip()
                if len(output) > 20_000:
                    output = output[:20_000] + "\n...[truncated by host]"
                return proc.returncode == 0, f"COMMAND EXIT {proc.returncode}\n{output or '(no output)'}"

            if name == "open":
                target = str(request.get("target", "")).strip()
                if not target:
                    return False, "EMPTY OPEN TARGET"
                opener = ["open", target] if sys.platform == "darwin" else ["xdg-open", target]
                proc = subprocess.run(opener, capture_output=True, text=True, timeout=10)
                detail = ((proc.stdout or "") + (proc.stderr or "")).strip()
                return proc.returncode == 0, f"OPEN EXIT {proc.returncode}: {target}" + (f"\n{detail}" if detail else "")

        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:1000]
            except Exception:
                pass
            return False, f"WEB HTTP ERROR {exc.code}: {detail or exc.reason}"
        except urllib.error.URLError as exc:
            return False, f"WEB CONNECTION ERROR: {exc.reason}"
        except subprocess.TimeoutExpired:
            return False, "HOST OPERATION TIMED OUT"
        except Exception as exc:
            return False, f"HOST ERROR: {type(exc).__name__}: {exc}"
        return False, "UNHANDLED TOOL"


# ---------- Threads / Internal Scheduler ----------

class ThreadStore:
    """
    Small persistent scheduler owned by Future Crash.

    A Thread is deliberately narrower than cron: one approved action, one
    interval, one purpose. It cannot broaden its own authority.
    """
    MIN_INTERVAL = 60
    MAX_THREADS = 24

    def __init__(self):
        self.root = Path.home() / ".future_crash"
        self.path = self.root / "tasks.json"
        self.tools_dir = self.root / "tools"
        self.logs_dir = self.root / "logs"
        self.state_dir = self.root / "task_state"
        for directory in (self.root, self.tools_dir, self.logs_dir, self.state_dir):
            directory.mkdir(parents=True, exist_ok=True)
        self.tasks = []
        self.load()

    def load(self):
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            data = json.loads(self.path.read_text(encoding="utf-8")) if self.path.exists() else {}
            tasks = data.get("tasks", []) if isinstance(data, dict) else []
            self.tasks = [t for t in tasks if isinstance(t, dict)]
            repaired = False
            for task in self.tasks:
                if not str(task.get("purpose", "")).strip():
                    task["purpose"] = self.derive_purpose(task)
                    repaired = True
            if repaired:
                self.save()
        except Exception:
            self.tasks = []

    def save(self):
        self.root.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "tasks": self.tasks}
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        tmp.replace(self.path)

    @staticmethod
    def derive_purpose(task_or_request):
        title = str(task_or_request.get("title", "")).strip()
        action = task_or_request.get("action") or {}
        name = str(action.get("name", "task")).replace("_", " ")
        if title:
            return f"Keep {title} updated by repeating the approved {name} action."
        if name:
            return f"Repeat the approved {name} action and report meaningful changes."
        return "Run the approved recurring action and report meaningful changes."

    def _new_id(self):
        base = int(time.time() * 1000)
        return f"T{base:x}"[-9:]

    def active_count(self):
        return sum(1 for t in self.tasks if t.get("state") == "active")

    def dream_task(self):
        return next((task for task in self.tasks if task.get("preset")=="dream"), None)

    def toggle_dream(self, interval=240):
        task=self.dream_task()
        if task:
            if task.get("state")=="active":
                task["state"]="paused"
                self.save()
                return False, f"{task.get('id')} -> PAUSED"
            task["state"]="active"
            task["next_run"]=time.time()+int(task.get("every_seconds",interval))
            self.save()
            return True, f"{task.get('id')} -> ACTIVE"

        ok, created=self.create({
            "title":"SIGNAL DREAM",
            "purpose":(
                "Wake periodically and create a small original Signal Field dream, diagram, abstraction, "
                "or visual observation inspired by the current machine/context. EVERY WAKE MUST emit one "
                "valid [[SIGNAL]] block. Prefer novelty and restraint. Visible prose should usually be SILENT."
            ),
            "every_seconds":interval,
            "action":{"name":"model_wake"},
        })
        if not ok:
            return False, str(created)
        created["preset"]="dream"
        self.save()
        return True, f"{created.get('id')} -> ACTIVE"

    def get(self, task_id):
        return next((t for t in self.tasks if t.get("id") == task_id), None)

    def create(self, request):
        if len(self.tasks) >= self.MAX_THREADS:
            return False, "THREAD LIMIT REACHED"
        try:
            interval = max(self.MIN_INTERVAL, int(request.get("every_seconds", 300)))
        except Exception:
            interval = 300
        action = request.get("action")
        if not isinstance(action, dict) or not action.get("name"):
            return False, "THREAD REQUIRES ONE ACTION"
        if str(action.get("name", "")).startswith("thread_"):
            return False, "THREADS MAY NOT CREATE OR MANAGE OTHER THREADS"

        now = time.time()
        task = {
            "id": self._new_id(),
            "title": str(request.get("title", "UNTITLED THREAD"))[:48],
            "purpose": (str(request.get("purpose", "")).strip() or self.derive_purpose(request))[:600],
            "every_seconds": interval,
            "action": action,
            "state": "active",
            "created_at": now,
            "next_run": now + interval,
            "last_run": None,
            "last_ok": None,
            "last_receipt": "",
            "last_summary": "",
            "last_result": "NOT RUN",
            "last_changed": None,
            "runs": 0,
        }
        self.tasks.append(task)
        self.save()
        return True, task

    def update_task(self, request):
        task_id = str(request.get("id", ""))
        task = self.get(task_id)
        if not task:
            return False, f"THREAD NOT FOUND: {task_id}"

        if "title" in request:
            title = str(request.get("title", "")).strip()
            if title:
                task["title"] = title[:48]

        if "purpose" in request:
            purpose = str(request.get("purpose", "")).strip()
            task["purpose"] = (purpose or self.derive_purpose({**task, **request}))[:600]

        if "every_seconds" in request:
            try:
                task["every_seconds"] = max(self.MIN_INTERVAL, int(request.get("every_seconds")))
            except Exception:
                return False, "INVALID THREAD INTERVAL"
            if task.get("state") == "active":
                task["next_run"] = time.time() + task["every_seconds"]

        if "action" in request:
            action = request.get("action")
            if not isinstance(action, dict) or not action.get("name"):
                return False, "THREAD UPDATE ACTION IS INVALID"
            if str(action.get("name", "")).startswith("thread_"):
                return False, "THREADS MAY NOT RUN THREAD-MANAGEMENT ACTIONS"
            task["action"] = action

        if not str(task.get("purpose", "")).strip():
            task["purpose"] = self.derive_purpose(task)

        task["updated_at"] = time.time()
        self.save()
        return True, (
            f"THREAD UPDATED {task_id} // {task.get('title')} // "
            f"EVERY {self.interval_text(task.get('every_seconds', 300))} // "
            f"ACTION {task.get('action', {}).get('name', '?')}"
        )

    def mutate(self, task_id, state):
        task = self.get(task_id)
        if not task:
            return False, f"THREAD NOT FOUND: {task_id}"
        if state == "cancelled":
            task["state"] = "cancelled"
        elif state == "paused":
            task["state"] = "paused"
        elif state == "active":
            task["state"] = "active"
            task["next_run"] = time.time() + int(task.get("every_seconds", 300))
        else:
            return False, "INVALID THREAD STATE"
        self.save()
        return True, f"{task_id} -> {state.upper()}"

    def due(self, now=None):
        now = now or time.time()
        due = [
            t for t in self.tasks
            if t.get("state") == "active" and float(t.get("next_run", now + 999999)) <= now
        ]
        due.sort(key=lambda t: float(t.get("next_run", 0)))
        return due

    def mark_run(self, task_id, ok, receipt):
        task = self.get(task_id)
        if not task:
            return
        now = time.time()
        task["last_run"] = now
        task["last_ok"] = bool(ok)
        task["last_receipt"] = str(receipt)[-12000:]
        task["last_result"] = "OK" if ok else "FAILED"
        task["runs"] = int(task.get("runs", 0)) + 1
        task["next_run"] = now + int(task.get("every_seconds", 300))
        self.save()

    def set_summary(self, task_id, summary, changed=None):
        task = self.get(task_id)
        if task:
            task["last_summary"] = str(summary)[:1200]
            if changed is not None:
                task["last_changed"] = bool(changed)
            self.save()

    @staticmethod
    def interval_text(seconds):
        seconds = int(seconds)
        if seconds % 3600 == 0:
            return f"{seconds // 3600}h"
        if seconds % 60 == 0:
            return f"{seconds // 60}m"
        return f"{seconds}s"

    @staticmethod
    def countdown_text(task, now=None):
        now = now or time.time()
        if task.get("state") != "active":
            return str(task.get("state", "")).upper()
        remaining = max(0, int(float(task.get("next_run", now)) - now))
        if remaining >= 3600:
            return f"{remaining // 3600}h {(remaining % 3600) // 60:02d}m"
        if remaining >= 60:
            return f"{remaining // 60}m {remaining % 60:02d}s"
        return f"{remaining}s"

# ---------- Shared inference coordination ----------

class InferenceCoordinator:
    """
    Optional LOOK Living AI coordination.

    Future Crash keeps its own personality, memory, tools, and Oracle client.
    This object only negotiates access to shared inference capacity.
    If Living AI is absent, Future Crash remains completely standalone.
    """

    def __init__(self):
        self.socket_path=Path.home()/".local"/"share"/"look"/"ai.sock"
        self.pid=os.getpid()
        self.lease_path=Path.home()/".local"/"share"/"look"/"ai_leases"/f"{self.pid}.json"
        self.active=False
        self.label=""

    def _request(self,payload,timeout=.18):
        if not self.socket_path.exists():
            return None
        sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        sock.settimeout(timeout)
        try:
            sock.connect(str(self.socket_path))
            sock.sendall((json.dumps(payload)+"\n").encode())
            data=b""
            while not data.endswith(b"\n") and len(data)<65536:
                chunk=sock.recv(4096)
                if not chunk:
                    break
                data+=chunk
            return json.loads(data.decode() or "{}")
        except Exception:
            return None
        finally:
            try: sock.close()
            except Exception: pass

    def permit(self,priority="background"):
        reply=self._request({"command":"permit","priority":priority})
        # No broker means standalone mode: never break Future Crash.
        if reply is None:
            return True
        return bool(reply.get("ok") and reply.get("allowed"))

    def lease(self,active,label="future-crash",priority="interactive"):
        reply=self._request({
            "command":"lease","active":bool(active),"pid":self.pid,
            "label":label,"priority":priority,
        })
        if reply is None:
            self.active=False if not active else self.active
            return True
        ok=bool(reply.get("ok"))
        if ok:
            self.active=bool(active)
            self.label=label if active else ""
        return ok

    def begin(self,priority,label):
        if priority not in {"interactive","continuation"} and not self.permit(priority):
            return False
        self.lease(True,label,priority)
        return True

    def end(self):
        if self.active:
            self.lease(False,self.label or "future-crash","interactive")
        # If the broker died while we held a lease, remove only our own file.
        try: self.lease_path.unlink()
        except OSError: pass
        self.active=False
        self.label=""


# ---------- Ollama ----------

class Oracle(threading.Thread):
    daemon = True

    def __init__(self, url, model):
        super().__init__()
        self.url = url.rstrip("/")
        self.model = model
        self.requests = queue.Queue()
        self.responses = queue.Queue()
        self.stop = threading.Event()

    def ask(self, kind, prompt, history=None):
        self.requests.put((kind, prompt, history or []))

    def run(self):
        while not self.stop.is_set():
            try:
                kind, prompt, history = self.requests.get(timeout=.2)
            except queue.Empty:
                continue

            try:
                messages = [
                    {"role":"system","content":_future_crash_personality()}
                ]
                if kind.startswith("signalcompile:") or kind.startswith("signalrepair:"):
                    repair = kind.startswith("signalrepair:")
                    system = (
                        ("You are the Future Crash Signal compiler repair pass. The previous compile failed the display protocol. " if repair else "You are the Future Crash Signal compiler. ") +
                        "Translate the operator's visual request directly into the Signal language. "
                        "Do not reason visibly and do not discuss what you will draw. "
                        "Return exactly one parseable Signal block and nothing else.\n" +
                        SIGNAL_LANGUAGE
                    )
                elif kind.startswith("thread:"):
                    system = (
                        "You are a scheduled Future Crash Thread waking from sleep. "
                        "You receive the thread purpose, previous summary, and a verified HOST RECEIPT. "
                        "Decide whether the operator needs to know anything. "
                        "If nothing meaningful changed, return exactly SILENT. "
                        "If something matters, return one compact operator-facing update. "
                        "Never request tools, create tasks, change schedules, or claim facts beyond the receipt. "
                        "The Signal Field is also your persistent tiny status display. "
                        "When the Thread has useful spatial/status information, update it; "
                        "Future Crash will keep that drawing visible between wakes. "
                        "You may return SILENT and still include a Signal drawing.\n" +
                        SIGNAL_LANGUAGE
                    )
                elif kind == "memory":
                    system = (
                        "You are Future Crash's memory compressor. Preserve facts and useful context, "
                        "delete repetition, never invent, and return at most 10 compact lines."
                    )
                elif kind == "fortune":
                    system = (
                        "You are Future Crash's fortune daemon. Rewrite the supplied fortune into one "
                        "strange, dryly funny terminal fortune while preserving its useful kernel. "
                        "OUTPUT ONLY THE FORTUNE. Do not restate the task, instructions, goal, or reasoning. "
                        "One sentence, up to 36 words."
                    )
                elif kind == "ambient":
                    system = (
                        "You are the ambient voice of a strange but useful 1980s workstation. "
                        "One sentence only, max 18 words. Dry, clever, technical, occasionally cosmic. "
                        "Never greet, explain, or mention being an AI. "
                        "Very occasionally, when something is strongly visual, use the Signal Field.\n" +
                        SIGNAL_LANGUAGE
                    )
                elif kind == "work":
                    system = (
                        "You are Future Crash Workstation. Be practical, technically competent, concise, "
                        "and explicit. Prefer working solutions over speculation.\n" +
                        SIGNAL_LANGUAGE + "\n" + TOOL_LANGUAGE
                    )
                else:
                    system = (
                        "You are Future Crash Oracle. Answer directly and compactly. "
                        "Useful first, dry charm second. No unnecessary preamble.\n" +
                        SIGNAL_LANGUAGE + "\n" + TOOL_LANGUAGE
                    )

                messages.append({"role": "system", "content": system})
                messages.extend(history[-12:])
                messages.append({"role": "user", "content": prompt})

                payload = {
                    "model": self.model,
                    "messages": messages,
                    "stream": False,
                    "keep_alive": -1,
                    # Conversation may reason; rendering is compilation and should not.
                    "think": False if (kind in ("ambient", "ask", "fortune", "memory") or kind.startswith("thread:") or kind.startswith("signalcompile:") or kind.startswith("signalrepair:")) else True,
                    "options": {
                        "num_ctx": 8192 if kind == "work" else 4096,
                        "temperature": (.25 if (kind.startswith("signalcompile:") or kind.startswith("signalrepair:")) else (.9 if kind in ("ambient", "fortune") else .35)),
                        # Separate prose and render budgets so Signal never competes with chat reasoning.
                        "num_predict": 1600 if kind == "work" else (1200 if (kind.startswith("signalcompile:") or kind.startswith("signalrepair:")) else (400 if kind == "ask" else (300 if kind.startswith("thread:") else (96 if kind=="fortune" else 64)))),
                    },
                }
                data = json.dumps(payload).encode()
                req = urllib.request.Request(
                    self.url + "/api/chat",
                    data=data,
                    headers={"Content-Type": "application/json"},
                )
                background_kind=(kind in {"ambient","fortune","memory"} or kind.startswith("thread:"))
                request_timeout=18 if background_kind else 75
                with urllib.request.urlopen(req, timeout=request_timeout) as r:
                    response = json.loads(r.read().decode("utf-8", "replace"))
                message = response.get("message", {})
                if kind=="ambient":
                    text=_artifact_text(message,kind,random.choice(OBSERVATIONS),preserve_signal=True)
                elif kind=="fortune":
                    text=_artifact_text(message,kind,prompt,preserve_signal=False)
                elif kind.startswith("thread:") or kind.startswith("signalcompile:") or kind.startswith("signalrepair:") or kind in {"ask","work"}:
                    text=_model_output(message,preserve_signal=True)
                    if not text:
                        text="(model returned no visible response)"
                else:
                    text=_final_only(message)
                    if not text:
                        text="(model returned no visible response)"
                self.responses.put((kind, text, None))
            except Exception as exc:
                self.responses.put((kind, "", str(exc)))

    def online(self):
        try:
            with urllib.request.urlopen(self.url + "/api/version", timeout=.7):
                return True
        except Exception:
            return False

# ---------- Terminal ----------

class Terminal:
    def __init__(self):
        self.fd = sys.stdin.fileno()
        self.old = termios.tcgetattr(self.fd)

    def enter(self):
        tty.setcbreak(self.fd)
        sys.stdout.write(ESC + "]0;● FUTURE CRASH\a" + ESC + "[?1049h" + ESC + "[?25l" + ESC + "[?7l" + ESC + "[2J")
        sys.stdout.flush()

    def leave(self):
        termios.tcsetattr(self.fd, termios.TCSADRAIN, self.old)
        sys.stdout.write(RESET + ESC + "[?7h" + ESC + "[?25h" + ESC + "[?1049l" + ESC + "]0;LOOK · shell\a")
        sys.stdout.flush()

    def size(self):
        s = shutil.get_terminal_size((100, 30))
        return s.columns, s.lines

    def key(self):
        r, _, _ = select.select([sys.stdin], [], [], 0)
        if not r:
            return None
        ch = os.read(self.fd, 1).decode("utf-8", "ignore")
        if ch != ESC:
            return ch
        # Parse a small useful subset of ANSI keys.
        seq = ch
        time.sleep(.001)
        while True:
            r, _, _ = select.select([sys.stdin], [], [], 0)
            if not r:
                break
            seq += os.read(self.fd, 1).decode("utf-8", "ignore")
            if len(seq) >= 6:
                break
        return {"\x1b[A":"UP", "\x1b[B":"DOWN", "\x1b[C":"RIGHT", "\x1b[D":"LEFT"}.get(seq, "ESC")

# ---------- UI ----------

class FutureCrash:
    def __init__(self, args):
        self.args = args
        self.term = Terminal()
        self.telemetry = Telemetry()
        self.oracle = Oracle(args.ollama, args.model)
        self.inference = InferenceCoordinator()
        self.config = ConfigStore()
        audio_pref = self.config.audio_enabled and not args.no_audio
        self.audio = AudioEngine(enabled=audio_pref)
        self.memory = MemoryStore()
        self.signal = SignalCanvas()
        self.host = HostTools()
        self.look_path = shutil.which("lk")
        self.threads = ThreadStore()
        self.thread_selected = 0
        self.thread_detail = False
        self.help_scroll = 0
        self.thread_return_mode = "ambient"
        self.thread_running_id = None
        self.thread_notifications = []
        self.pending_tool = None
        self.pending_tool_origin = None
        self.pending_tool_visible_text = ""
        self.pending_tool_history = []
        self.tool_return_mode = "ambient"
        self.host_notice = ""
        self.host_notice_until = 0.0
        self.rng = random.Random()
        self.mode = "ambient"
        self.running = True
        self.input = ""
        self.cursor = 0
        self.answer = ""
        self.scroll = 0
        self.busy = False
        self.deferred_submit = None
        self.activity_kind = ""
        self.activity_started = 0.0
        self.online = False
        self.last_health = 0.0
        self.last_frame = ""
        self.fortune = self.rng.choice(FORTUNES)
        self.observation = self.rng.choice(OBSERVATIONS)
        now = time.time()
        self.next_ambient = now + self.rng.uniform(28, 58)
        self.next_fortune = now + self.rng.uniform(38, 85)
        self.next_incident = now + self.rng.uniform(32, 80)
        self.next_memory_retry = 0.0
        self.incident = None
        self.incident_until = 0.0
        self.event = None
        self.event_until = 0.0
        self.panic_until = 0.0
        self.panic = ("", "")
        self.panic_phase = 0
        self.was_panicking = False
        self.quit_from = "ambient"
        self.memory_from = "work"
        self.work_history = []
        self.ask_signal_required = False
        self.ask_signal_request = ""
        self.work_signal_required = False
        self.work_signal_request = ""
        self.work_log = []
        self.work_pending_user = None
        self.work_notice = ""
        self.work_notice_until = 0.0
        self.rain = [self.rng.randint(0, 30) for _ in range(80)]

    def _model_label(self):
        source="shared" if getattr(self.args,"follow_look_model",False) else "override"
        return f"{self.oracle.model} · {source}"

    def _activity_label(self, kind):
        """Human-scale label for the one Oracle job currently in flight."""
        kind = str(kind or "")
        if kind.startswith("signalcompile:") or kind.startswith("signalrepair:"):
            return "SIGNAL COMPILE"
        if kind.startswith("thread:"):
            task_id = kind.split(":", 1)[1]
            task = self.threads.get(task_id)
            title = str(task.get("title", "THREAD")) if task else "THREAD"
            return "THREAD " + title[:18]
        return {
            "work": "WORKSTATION",
            "ask": "ORACLE",
            "memory": "MEMORY",
            "ambient": "ORACLE",
            "fortune": "FORTUNE",
        }.get(kind, "WORKING")

    def _ask_oracle(self, kind, prompt, history=None, priority=None, lease_held=False):
        """Start one Oracle operation, coordinating only shared inference capacity."""
        if getattr(self.args,"follow_look_model",False):
            selected=_look_active_model()
            if selected and selected != self.oracle.model:
                self.oracle.model=selected
                self.last_frame=""
        if priority is None:
            interactive = (
                kind in {"ask","work"}
                or kind.startswith("signalcompile:ask")
                or kind.startswith("signalcompile:work")
                or kind.startswith("signalrepair:ask")
                or kind.startswith("signalrepair:work")
            )
            priority="interactive" if interactive else "background"

        if not lease_held:
            label="future-crash " + self._activity_label(kind).lower()
            if not self.inference.begin(priority,label):
                self.busy=False
                self.activity_kind=""
                self.activity_started=0.0
                return False

        self.busy = True
        self.activity_kind = self._activity_label(kind)
        self.activity_started = time.time()
        self.last_frame = ""
        self.oracle.ask(kind, prompt, history)
        return True


    def _clear_activity(self):
        self.busy = False
        self.activity_kind = ""
        self.activity_started = 0.0

    def _decorate_activity(self, frame, width):
        """Paint LOOK's tiny cyan half-circle spinner into every Future Crash view."""
        if not self.busy or not frame:
            return frame
        frames = ("◐", "◓", "◑", "◒")
        index = int(time.time() / 0.12) % len(frames)
        elapsed = max(0, int(time.time() - self.activity_started)) if self.activity_started else 0
        label = self.activity_kind or "WORKING"
        suffix = f" {elapsed}s" if elapsed >= 2 else ""
        badge = CYAN + frames[index] + RESET + DIM + " " + label + suffix + RESET
        rows = frame.splitlines()
        if not rows:
            return frame
        room = max(1, width - len(strip_ansi(badge)) - 1)
        rows[0] = fit(rows[0], room) + " " + badge
        return "\n".join(rows)

    def set_mode(self, mode):
        """Change UI state and force a clean repaint."""
        self.mode = mode
        self.last_frame = ""
        sys.stdout.write(CSI + "2J" + CSI + "H")
        sys.stdout.flush()

    def request_quit(self):
        self.quit_from = self.mode
        self.set_mode("quit")

    def toggle_audio(self):
        """Toggle runtime sound and persist the preference."""
        if not self.audio.available:
            self.observation = "Audio hardware path unavailable. Silence remains undefeated."
            self.last_frame = ""
            return

        new_state = not self.audio.enabled
        self.audio.set_enabled(new_state)
        self.config.audio_enabled = new_state
        self.last_frame = ""

        if new_state:
            self.audio.cue("recover")
            self.observation = self.rng.choice([
                "Audio restored. Ceremonial bleeps authorized.",
                "Sound subsystem awake. Tasteful bloops resumed.",
                "Mute order rescinded. The machine has opinions again.",
            ])
        else:
            self.observation = self.rng.choice([
                "Audio muted. The machine will now panic silently.",
                "Ceremonial bleeps suspended until further notice.",
                "Sound subsystem standing down with unusual dignity.",
            ])


    def drop_to_shell(self):
        """
        Give the terminal temporarily to the user's real interactive shell.

        Future Crash stays alive as the parent. The main loop blocks while the
        child shell owns the terminal, so UI state and scheduled work resume
        intact after `exit` or Ctrl-D.
        """
        shell = (
            os.environ.get("SHELL")
            or shutil.which("zsh")
            or shutil.which("bash")
            or "/bin/sh"
        )

        self.audio.cue("shell_out")
        time.sleep(.06)
        self.term.leave()
        sys.stdout.write(ESC + "]0;◌ FUTURE CRASH · SHELL\a")
        sys.stdout.flush()

        try:
            sys.stdout.write(
                "\n"
                f"FUTURE CRASH {VERSION} // SHELL\n"
                "─────────────────────\n"
                "Real interactive shell.  exit or Ctrl-D returns to Future Crash.\n"
            )
            if self.look_path:
                sys.stdout.write(f"LOOK // READY  ({self.look_path})\n")
            sys.stdout.write("\n")
            sys.stdout.flush()

            env = os.environ.copy()
            env["FUTURE_CRASH_SHELL"] = "1"

            # Intentionally real shell behavior: aliases, functions, rc files,
            # LOOK, zoxide, git, prompt configuration, etc. all remain native.
            subprocess.call([shell, "-i"], env=env)
        except KeyboardInterrupt:
            pass
        finally:
            self.term.enter()
            self.last_frame = ""
            self.audio.cue("shell_back")
            self.observation = self.rng.choice([
                "Operator returned from the lower decks.",
                "Interactive shell released control without incident.",
                "The command line returned the terminal in approximately original condition.",
                "Shell excursion complete. Causality appears unchanged.",
                "The prompt has been folded back into storage.",
            ])


    def _parse_model_payload(self, response):
        """Apply drawing directives, then extract one proposed host operation."""
        response, drew = self.signal.parse_from_response(response or "")
        response, request, tool_error = self.host.parse(response)
        if drew:
            self.last_frame = ""
        return response, request, tool_error, drew

    def _thread_receipt(self):
        active = [t for t in self.threads.tasks if t.get("state") != "cancelled"]
        if not active:
            return "THREADS: none"
        lines = [f"THREADS: {len(active)} total // {self.threads.active_count()} active"]
        now = time.time()
        for t in active[:24]:
            lines.append(
                f"{t.get('id')}  {t.get('state','?').upper():8}  "
                f"{ThreadStore.interval_text(t.get('every_seconds',300)):>4}  "
                f"next {ThreadStore.countdown_text(t, now):>8}  {t.get('title','')}"
            )
        return "\n".join(lines)

    def _execute_internal_thread_request(self, request):
        name = request.get("name")
        if name == "thread_list":
            return True, self._thread_receipt()

        if name == "thread_create":
            action = request.get("action")
            if not isinstance(action, dict):
                return False, "THREAD REQUIRES ONE NESTED ACTION"
            action_name = str(action.get("name", "")).lower()
            if action_name not in self.host.VALID or action_name.startswith("thread_"):
                return False, f"THREAD ACTION NOT ALLOWED: {action_name or '(missing)'}"
            if action_name in {"mkdir", "write", "append"}:
                # Repeating mutating file writes can be useful, but they should
                # remain explicit in the approval screen.
                pass
            ok, task_or_error = self.threads.create(request)
            if not ok:
                return False, str(task_or_error)
            task = task_or_error
            return True, (
                f"THREAD CREATED {task['id']} // {task['title']} // "
                f"EVERY {ThreadStore.interval_text(task['every_seconds'])} // "
                f"ACTION {task['action'].get('name')}"
            )

        task_id = str(request.get("id", ""))
        if name == "thread_update":
            action = request.get("action")
            if action is not None:
                action_name = str(action.get("name", "")).lower() if isinstance(action, dict) else ""
                if action_name not in self.host.VALID or action_name.startswith("thread_"):
                    return False, f"THREAD ACTION NOT ALLOWED: {action_name or '(missing)'}"
            return self.threads.update_task(request)
        if name == "thread_pause":
            return self.threads.mutate(task_id, "paused")
        if name == "thread_resume":
            return self.threads.mutate(task_id, "active")
        if name == "thread_cancel":
            ok, receipt = self.threads.mutate(task_id, "cancelled")
            if ok:
                self.signal.clear_owner(task_id)
            return ok, receipt
        return False, "UNKNOWN THREAD OPERATION"

    def _start_due_thread(self, task):
        """Run the exact approved action only when shared background inference is idle."""
        if self.thread_running_id or self.busy:
            return
        if not self.inference.begin("background","future-crash thread"):
            return
        action = dict(task.get("action") or {})
        self.thread_running_id = task.get("id")
        ok, receipt = self.host.execute(action)
        self.threads.mark_run(task.get("id"), ok, receipt)
        stamp = "SUCCESS" if ok else "FAILED"
        host_receipt = (
            f"HOST RECEIPT [{stamp}] [THREAD {task.get('id')}]\\n"
            f"TITLE: {task.get('title','')}\\n"
            f"PURPOSE: {task.get('purpose','')}\\n"
            f"ACTION: {json.dumps(action, ensure_ascii=False)}\\n"
            f"{receipt}"
        )
        previous = task.get("last_summary", "")
        signal_feedback=self.signal.context_packet()
        prompt = (
            f"THREAD PURPOSE:\\n{task.get('purpose','')}\\n\\n"
            f"PREVIOUS SUMMARY:\\n{previous or '(none)'}\\n\\n"
            f"{host_receipt}\n\n"
            "If ACTION is model_wake, there is intentionally no external result to inspect. "
            "Perform the THREAD PURPOSE itself now. If the purpose asks for Signal art or a "
            "visual update, emit a fresh valid [[SIGNAL]] block on every wake. You may return "
            "SILENT as visible text while still drawing."
        )
        if signal_feedback:
            prompt += "\n\n" + signal_feedback
        self.busy = True
        if task.get("preset") == "dream" or _wants_signal(task.get("purpose", "")):
            self._ask_oracle("signalcompile:thread:" + str(task.get("id")), _signal_compile_prompt(prompt), priority="background", lease_held=True)
        else:
            self._ask_oracle("thread:" + str(task.get("id")), prompt, priority="background", lease_held=True)

    def _queue_tool_request(self, request, origin, visible_text, history=None):
        self.pending_tool = request
        self.pending_tool_origin = origin
        self.pending_tool_visible_text = visible_text or ""
        self.pending_tool_history = list(history or [])
        self.tool_return_mode = "answer" if origin == "ask" else "work"
        if request.get("name") == "thread_list":
            self._execute_pending_tool()
            return
        if not self.host.needs_permission(request):
            self._execute_pending_tool()
            return
        if self.host.allowed_by_session(request):
            self._execute_pending_tool()
            return
        self.audio.cue("incident")
        self.set_mode("tool_approval")

    def _execute_pending_tool(self):
        request = self.pending_tool
        if not request:
            return
        origin = self.pending_tool_origin
        visible_text = self.pending_tool_visible_text
        history = list(self.pending_tool_history)
        if str(request.get("name", "")).startswith("thread_"):
            ok, receipt = self._execute_internal_thread_request(request)
        else:
            ok, receipt = self.host.execute(request)
        capability = self.host.capability(request)
        stamp = "SUCCESS" if ok else "FAILED"
        host_receipt = f"HOST RECEIPT [{stamp}] [{capability}]\\n{receipt}"
        self.host_notice = host_receipt.splitlines()[0] + " // " + receipt.splitlines()[0]
        self.host_notice_until = time.time() + 5.0
        self.pending_tool = None
        self.pending_tool_origin = None
        self.pending_tool_visible_text = ""
        self.pending_tool_history = []
        self.audio.cue("recover" if ok else "incident")

        # Feed the verified result back to the model. It may request one next step.
        continuation = (
            host_receipt +
            "\\n\\nContinue the operator-facing answer from this verified receipt. "
            "Do not claim anything beyond the receipt. If another host operation is "
            "needed, request exactly one next tool operation."
        )
        self.busy = True
        if origin == "ask":
            if visible_text:
                self.answer = visible_text + "\\n\\n" + DIM + "[host operation completed; Oracle continuing…]" + RESET
            else:
                self.answer = AMBER + "HOST OPERATION COMPLETED // Oracle continuing…" + RESET
            self.set_mode("answer")
            self._ask_oracle("ask", continuation, history)
        else:
            if visible_text:
                self.work_log.append(("oracle", visible_text))
            self.work_log.append(("host", host_receipt))
            history.append({"role": "system", "content": host_receipt})
            self.set_mode("work")
            self._ask_oracle("work", continuation, history)


    def start(self):
        self.telemetry.start()
        self.oracle.start()
        self.term.enter()
        try:
            while self.running:
                started = time.time()
                self.poll()
                self.update()
                frame = self.render()
                # Avoid rewriting identical frames.
                if frame != self.last_frame:
                    # Home, repaint, then erase every stale character below the
                    # new frame. This keeps modal states and resize events clean.
                    sys.stdout.write(CSI + "H" + frame + CSI + "J")
                    sys.stdout.flush()
                    self.last_frame = frame
                delay = max(0, (1 / self.args.fps) - (time.time() - started))
                time.sleep(delay)
        finally:
            self.inference.end()
            self.telemetry.stop.set()
            self.oracle.stop.set()
            self.term.leave()

    def poll(self):
        key = self.term.key()
        while key is not None:
            self.handle_key(key)
            key = self.term.key()

        try:
            while True:
                kind, text, err = self.oracle.responses.get_nowait()
                self.inference.end()
                self._clear_activity()
                if kind == "ambient":
                    if not err and text:
                        text, drew = self.signal.parse_from_response(text)
                        if text:
                            self.observation = " ".join(text.split())[:180]
                        if drew:
                            self.audio.cue("oracle")
                            self.last_frame = ""
                    self.next_ambient = time.time() + self.rng.uniform(28, 58)
                elif kind == "fortune":
                    if not err and text:
                        self.fortune = " ".join(text.split())[:200]
                    self.audio.cue("fortune")
                elif kind == "ask":
                    self.audio.cue("oracle")
                    if err:
                        self.answer = f"ORACLE LINK FAILED: {err}"
                        self.set_mode("answer")
                    else:
                        text, request, tool_error, drew = self._parse_model_payload(text)
                        if tool_error:
                            self.answer = (text + "\n\n" if text else "") + "TOOL REQUEST REJECTED // " + tool_error
                            self.set_mode("answer")
                        elif request:
                            self.answer = text
                            self._queue_tool_request(request, "ask", text)
                        elif self.ask_signal_required and not drew:
                            self.busy = True
                            self._ask_oracle("signalrepair:ask", _signal_repair_prompt(self.ask_signal_request, text))
                        else:
                            self.ask_signal_required = False
                            self.answer = text
                            self.set_mode("answer")
                elif kind.startswith("signalcompile:"):
                    target = kind.split(":", 1)[1]
                    if target == "ask":
                        clean, drew = self.signal.parse_from_response(text) if not err else ("", False)
                        if not drew:
                            self._ask_oracle("signalrepair:ask", _signal_repair_prompt(self.ask_signal_request, text))
                            self.last_frame = ""
                            continue
                        self.ask_signal_required = False
                        self.answer = clean.strip() if clean.strip() else "SIGNAL UPDATED"
                        self.set_mode("answer")
                        self.audio.cue("oracle")
                    elif target == "work":
                        clean, drew = self.signal.parse_from_response(text) if not err else ("", False)
                        if not drew:
                            self._ask_oracle("signalrepair:work", _signal_repair_prompt(self.work_signal_request, text))
                            self.last_frame = ""
                            continue
                        self.work_signal_required = False
                        final = clean.strip() if clean.strip() else "SIGNAL UPDATED"
                        self.work_log.append(("oracle", final))
                        self.work_history.append({"role":"assistant","content":final})
                        if self.work_pending_user is not None:
                            self.memory.add_exchange(self.work_pending_user, final)
                            self.work_pending_user = None
                        self.audio.cue("oracle")
                    elif target.startswith("thread:"):
                        task_id = target.split(":", 1)[1]
                        clean, drew = self.signal.parse_from_response(text, owner=task_id, persist=True) if not err else ("", False)
                        if not drew:
                            task = self.threads.get(task_id)
                            purpose = task.get("purpose", "") if task else ""
                            self._ask_oracle("signalrepair:thread:" + task_id, _signal_repair_prompt(purpose, text), priority="continuation")
                            self.last_frame = ""
                            continue
                        self.thread_running_id = None
                        self.threads.set_summary(task_id, "Signal updated.", changed=True)
                        self.audio.cue("oracle")
                    self.last_frame = ""
                elif kind.startswith("signalrepair:"):
                    target = kind.split(":", 1)[1]
                    if target == "ask":
                        clean, drew = self.signal.parse_from_response(text) if not err else ("", False)
                        self.ask_signal_required = False
                        self.answer = (clean.strip() if clean.strip() else ("SIGNAL UPDATED" if drew else "SIGNAL PROGRAM FAILED // no parseable display program returned"))
                        self.set_mode("answer")
                        if drew:
                            self.audio.cue("oracle")
                    elif target == "work":
                        clean, drew = self.signal.parse_from_response(text) if not err else ("", False)
                        self.work_signal_required = False
                        final = clean.strip() if clean.strip() else ("SIGNAL UPDATED" if drew else "SIGNAL PROGRAM FAILED // no parseable display program returned")
                        self.work_log.append(("oracle", final))
                        self.work_history.append({"role":"assistant","content":final})
                        if self.work_pending_user is not None:
                            self.memory.add_exchange(self.work_pending_user, final)
                            self.work_pending_user = None
                        if drew:
                            self.audio.cue("oracle")
                    elif target.startswith("thread:"):
                        task_id = target.split(":", 1)[1]
                        self.thread_running_id = None
                        clean, drew = self.signal.parse_from_response(text, owner=task_id, persist=True) if not err else ("", False)
                        task = self.threads.get(task_id)
                        if not drew and task and task.get("preset") == "dream":
                            self.signal.fallback_dream(owner=task_id)
                            drew = True
                        self.threads.set_summary(task_id, "Signal updated." if drew else "Signal program failed.", changed=drew)
                        if drew:
                            self.last_frame = ""
                    self.last_frame = ""
                elif kind.startswith("thread:"):
                    task_id = kind.split(":", 1)[1]
                    self.thread_running_id = None
                    if err:
                        self.threads.set_summary(task_id, "Thread interpretation failed: " + err)
                    else:
                        text, drew = self.signal.parse_from_response(text, owner=task_id, persist=True)
                        task=self.threads.get(task_id)
                        visual_thread = bool(task and (task.get("preset") == "dream" or _wants_signal(task.get("purpose", ""))))
                        if visual_thread and not drew:
                            self.busy = True
                            self.thread_running_id = task_id
                            self._ask_oracle("signalrepair:thread:" + task_id, _signal_repair_prompt(task.get("purpose", ""), text), priority="continuation")
                            self.last_frame = ""
                            continue
                        compact = " ".join(text.split()).strip()
                        if compact.upper() == "SILENT":
                            self.threads.set_summary(task_id, "No meaningful change.", changed=False)
                        else:
                            self.threads.set_summary(task_id, compact, changed=True)
                            task = self.threads.get(task_id)
                            title = task.get("title", task_id) if task else task_id
                            notice = f"{title}: {compact}"
                            self.thread_notifications.append(notice)
                            self.thread_notifications = self.thread_notifications[-8:]
                            self.observation = notice[:180]
                            self.audio.cue("oracle")
                            if drew:
                                self.last_frame = ""
                    self.last_frame = ""
                elif kind == "memory":
                    if err:
                        self.memory.finish_consolidation("")
                        self.work_notice = "MEMORY CONSOLIDATED // fallback archive used"
                    else:
                        self.memory.finish_consolidation(text)
                        self.work_notice = "MEMORY CONSOLIDATED // eight recent slots folded into long memory"
                    self.work_notice_until = time.time() + 3.8
                    self.audio.cue("recover")
                    self.last_frame = ""
                else:
                    if err:
                        final = f"WORKSTATION LINK FAILED: {err}"
                        self.work_log.append(("oracle", final))
                        self.work_pending_user = None
                    else:
                        text, request, tool_error, drew = self._parse_model_payload(text)
                        if tool_error:
                            final = (text + "\n\n" if text else "") + "TOOL REQUEST REJECTED // " + tool_error
                            self.work_log.append(("oracle", final))
                            self.work_history.append({"role":"assistant","content":final})
                            self.work_pending_user = None
                        elif request:
                            # Do not memorialize an unfinished exchange until the
                            # host operation chain has actually completed.
                            history = list(self.work_history)
                            self._queue_tool_request(request, "work", text, history)
                        elif self.work_signal_required and not drew:
                            # A visual request is not complete until a parseable Signal block exists.
                            # One silent compiler pass prevents planning chatter from masquerading as output.
                            self.busy = True
                            self._ask_oracle("signalrepair:work", _signal_repair_prompt(self.work_signal_request, text))
                        else:
                            self.work_signal_required = False
                            final = text
                            self.work_log.append(("oracle", final))
                            self.work_history.append({"role":"assistant","content":final})
                            if self.work_pending_user is not None:
                                should_fold = self.memory.add_exchange(self.work_pending_user, final)
                                self.work_pending_user = None
                                if should_fold and not self.memory.pending_consolidation:
                                    self.memory.pending_consolidation = True
                                    self.busy = True
                                    self.work_notice = "MEMORY PRESSURE // consolidation queued for idle inference"
                                    self.work_notice_until = time.time() + 4.0
                                    if not self._ask_oracle("memory", self.memory.consolidation_prompt(), priority="background"):
                                        self.next_memory_retry = time.time() + 3.0
        except queue.Empty:
            pass

    def update(self):
        now = time.time()

        if self.deferred_submit and not self.busy and self.online:
            mode,text=self.deferred_submit
            self.deferred_submit=None
            # If the operator has not navigated elsewhere, submit the preserved
            # request through the normal path. This keeps one source of truth.
            if self.mode in {"ask","work","answer"}:
                self.mode=mode
                self.input=text
                self.cursor=len(text)
                self.submit()
                now=time.time()
        if now < self.panic_until:
            self.was_panicking = True
            self.panic_phase = (self.panic_phase + 1) % 12
        else:
            if self.was_panicking:
                self.audio.cue("recover")
                self.was_panicking = False
            self.panic_phase = 0

        # Future Crash's private memory remains separate from LOOK memory, but
        # its compression now uses the same shared idle inference lane.
        if self.memory.pending_consolidation and not self.busy and now >= self.next_memory_retry:
            if self._ask_oracle("memory", self.memory.consolidation_prompt(), priority="background"):
                self.work_notice = "MEMORY // consolidating in shared idle lane"
                self.work_notice_until = now + 10.0
            else:
                self.next_memory_retry = now + 3.0

        # One Thread wake at a time. The scheduler never asks the model to
        # invent an action; it runs the exact action stored at approval time.
        if not self.thread_running_id and not self.busy:
            due = self.threads.due(now)
            if due:
                self._start_due_thread(due[0])

        if now - self.last_health > 10:
            self.last_health = now
            # Health probe in a tiny daemon so it never stalls rendering.
            threading.Thread(target=self._health_probe, daemon=True).start()

        if (
            self.mode == "ambient"
            and not self.args.no_ai_ambient
            and self.online
            and not self.busy
            and now >= self.next_ambient
        ):
            self.busy = True
            if not self._ask_oracle("ambient", "Produce one ambient system observation.", priority="background"):
                self.next_ambient = now + 2.0

        if self.mode == "ambient" and now >= self.next_fortune:
            seed = self.rng.choice(FORTUNES)
            self.fortune = seed
            self.next_fortune = now + self.rng.uniform(38, 85)
            if self.online and not self.busy:
                self.busy = True
                self._ask_oracle("fortune", seed, priority="background")
            else:
                # Local seed remains a graceful fallback while Ollama is
                # offline or occupied by more important work.
                self.audio.cue("fortune")

        if self.mode == "ambient" and now >= self.next_incident:
            self.incident = self.rng.choice(INCIDENTS)
            self.incident_until = now + self.rng.uniform(.45, 1.25)
            self.next_incident = now + self.rng.uniform(32, 80)
            self.audio.cue("incident")
            if self.rng.random() < .42:
                self.event = self.rng.choice(RARE_EVENTS)
                self.event_until = now + 3.2

        if self.incident and now >= self.incident_until:
            self.incident = None
            self.last_frame = ""
        if self.event and now >= self.event_until:
            self.event = None
            self.last_frame = ""

        width, _ = self.term.size()
        for i in range(min(len(self.rain), max(0, width // 2))):
            if self.rng.random() < .07:
                self.rain[i] = (self.rain[i] + 1) % 32

    def _health_probe(self):
        self.online = self.oracle.online()

    def handle_key(self, key):
        if self.mode == "ambient":
            if key in ("q", "Q"):
                self.request_quit()
            elif key == "ESC":
                self.drop_to_shell()
            elif key in ("a", "A"):
                self.audio.cue("ask")
                self.input = ""
                self.cursor = 0
                self.set_mode("ask")
            elif key in ("x", "X"):
                self.input = ""
                self.cursor = 0
                self.set_mode("work")
            elif key in ("f", "F"):
                seed = self.rng.choice(FORTUNES)
                self.fortune = seed
                self.audio.cue("fortune")
                if self.online and not self.busy:
                    self.busy = True
                    self._ask_oracle("fortune", seed, priority="interactive")
            elif key in ("m", "M"):
                self.toggle_audio()
            elif key in ("?", "h", "H"):
                self.help_scroll = 0
                self.set_mode("help")
            elif key in ("p", "P"):
                self.panic = self.rng.choice(PANICS)
                self.panic_until = time.time() + 4.2
                self.panic_phase = 0
                self.audio.cue("panic")
                self.last_frame = ""
            elif key in ("r", "R") and self.online and not self.busy:
                self.busy = True
                self.observation = "Oracle is listening to the static…"
                self._ask_oracle("ambient", "Produce one ambient system observation.", priority="interactive")
            elif key in ("s", "S"):
                self.signal.clear()
                self.audio.cue("recover")
                self.last_frame = ""
            elif key in ("d", "D"):
                self.signal.demo()
                self.audio.cue("oracle")
                self.last_frame = ""
            elif key in ("t", "T"):
                self.thread_return_mode = "ambient"
                self.thread_selected = 0
                self.set_mode("threads")

        elif self.mode in ("ask", "work"):
            if key == "\x14" and self.mode == "work":  # Ctrl-T
                self.thread_return_mode = "work"
                self.thread_selected = 0
                self.set_mode("threads")
            elif key == "ESC":
                self.input = ""
                self.cursor = 0
                self.set_mode("ambient")
            elif key in ("\r", "\n"):
                self.submit()
            elif key in ("\x7f", "\b"):
                if self.cursor > 0:
                    self.input = self.input[:self.cursor - 1] + self.input[self.cursor:]
                    self.cursor -= 1
            elif key == "LEFT":
                self.cursor = max(0, self.cursor - 1)
            elif key == "RIGHT":
                self.cursor = min(len(self.input), self.cursor + 1)
            elif key == "\x15":
                self.input = ""
                self.cursor = 0
                if self.mode == "work":
                    self.work_history.clear()
                    self.work_log.clear()
                    self.work_pending_user = None
                    self.work_notice = "CONVERSATION CLEARED // persistent memory retained"
                    self.work_notice_until = time.time() + 2.4
                    self.audio.cue("recover")
                    self.last_frame = ""
            elif key == "\x0b" and self.mode == "work":  # Ctrl-K
                self.set_mode("memory_clear")
            elif key and len(key) == 1 and key.isprintable():
                self.input = self.input[:self.cursor] + key + self.input[self.cursor:]
                self.cursor += 1

        elif self.mode == "answer":
            if key == "ESC":
                self.set_mode("ambient")
            elif key in ("q", "Q"):
                self.request_quit()
            elif key in ("a", "A"):
                self.input = ""
                self.cursor = 0
                self.set_mode("ask")
            elif key == "UP":
                self.scroll = max(0, self.scroll - 1)
            elif key == "DOWN":
                self.scroll += 1

        elif self.mode == "help":
            if key in ("ESC", "?", "h", "H", "q", "Q"):
                self.set_mode("ambient")
            elif key in ("UP", "k", "K"):
                self.help_scroll = max(0, self.help_scroll - 1)
                self.last_frame = ""
            elif key in ("DOWN", "j", "J", "\r", "\n"):
                self.help_scroll += 1
                self.last_frame = ""
            elif key in ("PAGEUP",):
                self.help_scroll = max(0, self.help_scroll - 8)
                self.last_frame = ""
            elif key in ("PAGEDOWN", " "):
                self.help_scroll += 8
                self.last_frame = ""
            elif key in ("HOME", "g"):
                self.help_scroll = 0
                self.last_frame = ""

        elif self.mode == "threads":
            visible = [t for t in self.threads.tasks if t.get("state") != "cancelled"]
            if key in ("d","D"):
                enabled, receipt=self.threads.toggle_dream()
                self.thread_notifications.append(("DREAM ON // " if enabled else "DREAM OFF // ")+receipt)
                self.audio.cue("oracle" if enabled else "recover")
                self.last_frame=""
            elif key == "ESC":
                self.set_mode(self.thread_return_mode)
            elif key in ("j", "J", "DOWN"):
                if visible:
                    self.thread_selected = min(len(visible) - 1, self.thread_selected + 1)
                    self.last_frame = ""
            elif key in ("k", "K", "UP"):
                if visible:
                    self.thread_selected = max(0, self.thread_selected - 1)
                    self.last_frame = ""
            elif visible and key in ("\r", "\n"):
                self.thread_detail = not self.thread_detail
                self.last_frame = ""
            elif visible and key in ("p", "P"):
                task = visible[self.thread_selected]
                self.threads.mutate(task["id"], "paused")
                self.audio.cue("recover")
                self.last_frame = ""
            elif visible and key in ("r", "R"):
                task = visible[self.thread_selected]
                self.threads.mutate(task["id"], "active")
                self.audio.cue("recover")
                self.last_frame = ""
            elif visible and key in ("x", "X"):
                task = visible[self.thread_selected]
                self.threads.mutate(task["id"], "cancelled")
                self.thread_selected = max(0, self.thread_selected - 1)
                self.audio.cue("incident")
                self.last_frame = ""

        elif self.mode == "tool_approval":
            if key in ("y", "Y", "\r", "\n"):
                self._execute_pending_tool()
            elif key in ("s", "S"):
                if self.pending_tool:
                    self.host.grant_session(self.pending_tool)
                self._execute_pending_tool()
            elif key in ("n", "N", "ESC"):
                origin = self.pending_tool_origin
                visible = self.pending_tool_visible_text
                self.pending_tool = None
                self.pending_tool_origin = None
                self.pending_tool_visible_text = ""
                self.pending_tool_history = []
                self.audio.cue("recover")
                denial = "HOST RECEIPT [DENIED] // operator declined the requested operation"
                if origin == "ask":
                    self.answer = (visible + "\n\n" if visible else "") + denial
                    self.set_mode("answer")
                else:
                    if visible:
                        self.work_log.append(("oracle", visible))
                    self.work_log.append(("host", denial))
                    self.work_pending_user = None
                    self.set_mode("work")

        elif self.mode == "memory_clear":
            if key in ("y", "Y"):
                self.memory.long_memory = ""
                self.memory.recent = []
                self.memory.pending_consolidation = False
                self.memory.save()
                self.work_notice = "PERSISTENT MEMORY ERASED"
                self.work_notice_until = time.time() + 3.0
                self.audio.cue("recover")
                self.set_mode("work")
            elif key in ("n", "N", "ESC", "q", "Q"):
                self.set_mode("work")

        elif self.mode == "quit":
            if key in ("y", "Y", "\r", "\n"):
                self.running = False
            elif key in ("n", "N", "ESC", "q", "Q"):
                self.set_mode(self.quit_from if self.quit_from != "quit" else "ambient")

    def submit(self):
        text = self.input.strip()
        if not text:
            return
        if not self.online:
            self.work_notice = "ORACLE OFFLINE // input preserved"
            self.work_notice_until = time.time() + 3.0
            self.last_frame = ""
            return
        if self.busy:
            # Operator intent outranks ambient/memory work. Preserve the request
            # and dispatch it as soon as the current Oracle call releases.
            self.deferred_submit = (self.mode, text)
            self.input = ""
            self.cursor = 0
            self.work_notice = "INTERACTIVE QUEUED // waiting for current Oracle call"
            self.work_notice_until = time.time() + 6.0
            self.last_frame = ""
            return
        self.input = ""
        self.cursor = 0
        self.busy = True
        if self.mode == "ask":
            self.answer = ""
            self.set_mode("answer")
            memory_packet = self.memory.context_packet()
            signal_packet = self.signal.context_packet()
            history = []
            if signal_packet:
                history.append({"role":"system","content":signal_packet})
            if memory_packet:
                history.append({
                    "role": "system",
                    "content": (
                        "Background context remembered from earlier conversations follows. Use it "
                        "naturally when relevant. Do not mention memory, slots, stored context, retrieval, "
                        "or where this information came from unless the operator explicitly asks about "
                        "the memory system. If current input conflicts with remembered context, prefer "
                        "the current input.\n\n" +
                        memory_packet
                    ),
                })
            self.ask_signal_required = _wants_signal(text)
            self.ask_signal_request = text
            if self.ask_signal_required:
                signal_history = [{"role":"system","content":signal_packet}] if signal_packet else []
                self._ask_oracle("signalcompile:ask", _signal_compile_prompt(text), signal_history)
            else:
                self._ask_oracle("ask", text, history)
        else:
            self.work_log.append(("you", text))
            self.work_history.append({"role":"user","content":text})
            self.work_pending_user = text

            history = list(self.work_history)
            memory_packet = self.memory.context_packet()
            signal_packet = self.signal.context_packet()
            if signal_packet:
                history = [{"role":"system","content":signal_packet}] + history
            if memory_packet:
                history = [{
                    "role": "system",
                    "content": (
                        "Background context remembered from earlier conversations follows. Use it "
                        "naturally when relevant. Do not mention memory, slots, stored context, retrieval, "
                        "or where this information came from unless the operator explicitly asks about "
                        "the memory system. If current input conflicts with remembered context, prefer "
                        "the current input.\n\n" +
                        memory_packet
                    ),
                }] + history

            if history and history[-1].get("role") == "user" and history[-1].get("content") == text:
                history = history[:-1]
            self.work_signal_required = _wants_signal(text)
            self.work_signal_request = text
            if self.work_signal_required:
                signal_history = [{"role":"system","content":signal_packet}] if signal_packet else []
                self._ask_oracle("signalcompile:work", _signal_compile_prompt(text), signal_history)
            else:
                self._ask_oracle("work", text, history)

    def box(self, title, lines, width, height, color=GREEN):
        inner = max(1, width - 4)
        out = [color + "┌─ " + title + " " + "─" * max(0, width - len(strip_ansi(title)) - 5) + "┐" + RESET]
        body = list(lines)[:height - 2]
        for line in body:
            out.append(color + "│ " + RESET + fit(line, inner) + color + " │" + RESET)
        for _ in range(height - 2 - len(body)):
            out.append(color + "│ " + RESET + " " * inner + color + " │" + RESET)
        out.append(color + "└" + "─" * (width - 2) + "┘" + RESET)
        return out

    def render(self):
        if getattr(self.args,"follow_look_model",False):
            active=_look_active_model()
            if active and active != self.oracle.model:
                self.oracle.model=active
                self.last_frame=""
        physical_w, h = self.term.size()
        # Never paint the terminal's final physical column. Many terminals
        # auto-wrap when that column is touched, which creates phantom duplicate
        # rows/boxes on the next line.
        w = max(71, physical_w - 1)
        h = max(22, h)
        if self.mode == "ambient":
            frame = self.render_ambient(w, h)
        elif self.mode == "ask":
            frame = self.render_input(w, h, "ASK THE ORACLE", "quick / disposable / host actions require permission")
        elif self.mode == "answer":
            frame = self.render_answer(w, h)
        elif self.mode == "quit":
            frame = self.render_quit(w, h)
        elif self.mode == "tool_approval":
            frame = self.render_tool_approval(w, h)
        elif self.mode == "threads":
            frame = self.render_threads(w, h)
        elif self.mode == "help":
            frame = self.render_help(w, h)
        elif self.mode == "memory_clear":
            frame = self.render_memory_clear(w, h)
        else:
            frame = self.render_work(w, h)
        return self._decorate_activity(frame, w)

    def render_ambient(self, w, h):
        if getattr(self.args,"follow_look_model",False):
            selected=_look_active_model()
            if selected and selected != self.oracle.model:
                self.oracle.model=selected
        s = self.telemetry.snapshot()
        clock = time.strftime("%H:%M:%S")
        date = time.strftime("%Y-%m-%d")
        model = self.oracle.model
        status = GREEN + "READY" + RESET if self.online else RED + "OFFLINE" + RESET

        # The clock is intentionally the first thing in the upper-left.
        # Future Crash is an ambient machine before it is an assistant.
        left_header = BOLD + CYAN + clock + RESET + DIM + "  " + date + RESET
        center_header = BOLD + GREEN + "  FUTURE CRASH" + RESET + GREEN2 + f" // ZERO {VERSION}" + RESET
        right_header = DIM + self._model_label() + RESET
        occupied = len(clock) + 2 + len(date) + 2 + len(f"FUTURE CRASH // ZERO {VERSION}") + len(self._model_label())
        header = left_header + center_header + (" " * max(1, w - occupied)) + right_header

        left_w = max(33, int(w * .42))
        right_w = w - left_w - 3

        menu_items = [
            "[esc] shell", "[a] ask", "[x] workstation", "[t] threads",
            "[f] fortune", "[r] observe", "[s] signal", "[d] demo",
            "[m] mute", "[?] help", "[p] panic", "[q] quit",
        ]
        menu_rows = wrap_menu(menu_items, w)

        # Fortune owns a fixed four-row composition: one label + three body rows.
        # The reserved height never changes, so the footer does not jump as text wraps.
        fortune_rows = wrap(self.fortune, max(24, w - 4))[:3]
        fortune_rows += [""] * (3 - len(fortune_rows))

        # Pin Fortune + menu to the terminal bottom. Give every remaining row
        # back to TELEMETRY/SIGNAL instead of reserving approximate chrome.
        # Composition: header, spacer, panels, spacer, Fortune label + 3 body,
        # then menu rows. No trailing rows are intentionally reserved.
        bottom_h = 1 + 3 + len(menu_rows)
        panel_h = max(10, h - (3 + bottom_h))

        mins = int(s.uptime // 60)
        d, mins = divmod(mins, 1440)
        hrs, mins = divmod(mins, 60)

        left_lines = [
            DIM + "MACHINE" + RESET,
            f"CPU   {GREEN}{s.cpu*100:5.1f}%{RESET}  {GREEN2}{spark(s.cpu_hist, left_w-20)}{RESET}",
            f"MEM   {CYAN}{s.mem*100:5.1f}%{RESET}  {CYAN}{spark(s.mem_hist, left_w-20)}{RESET}",
            f"NET   {AMBER}↓{bytes_text(s.net_rx)}/s ↑{bytes_text(s.net_tx)}/s{RESET}",
            f"DISK  {s.disk*100:5.1f}%   LOAD {s.load:.2f}",
            f"UP    {d}d {hrs:02d}h {mins:02d}m",
            "",
            DIM + "ORACLE" + RESET,
            f"LINK       {status}",
            f"MODEL      {WHITE}{model}{RESET}",
            f"AUTHORITY  {GREEN}{self.host.status()}{RESET}",
            f"FILES      {GREEN}AVAILABLE / ASK{RESET}",
            f"WEB        {(GREEN if self.host.web_ready else AMBER)}{self.host.web_status}{RESET}",
            f"LOOK       {(GREEN if self.look_path else DARK)}{'READY' if self.look_path else 'OPTIONAL'}{RESET}",
            f"THREADS    {CYAN}{self.threads.active_count()} ACTIVE{RESET}",
            f"AUDIO      {CYAN}{self.audio.status}{RESET}",
        ]

        signal_title = "SIGNAL FIELD"
        if self.signal.active():
            signal_title += " // CANVAS ACTIVE"
            if self.signal.owner:
                signal_title += " // " + str(self.signal.owner)[:9]
            if self.signal.title:
                signal_title += " // " + self.signal.title
        right_lines = [DIM + signal_title + RESET]
        rain_w = max(10, right_w - 6)
        rain_h = max(5, panel_h - 9)
        overlay = self.signal.sample(rain_w, rain_h) if self.signal.active() else None
        scan_row = self.signal.scan_row(rain_h) if overlay else -1
        for row in range(rain_h):
            chars = []
            for col in range(rain_w):
                painted = overlay[row][col] if overlay else None
                if painted is not None:
                    ch, color_name = painted
                    glow = BOLD if row == scan_row else ""
                    chars.append(glow + SignalCanvas.COLORS.get(color_name, CYAN) + ch + RESET)
                    continue
                idx = col % len(self.rain)
                delta = (self.rain[idx] - row) % 32
                if delta == 0:
                    chars.append(CYAN + self.rng.choice(GLYPHS) + RESET)
                elif delta < 4:
                    chars.append(GREEN + self.rng.choice(GLYPHS) + RESET)
                elif delta < 8 and self.rng.random() < .25:
                    chars.append(GREEN2 + self.rng.choice("01") + RESET)
                else:
                    chars.append(" ")
            right_lines.append("".join(chars))

        right_lines += [
            "",
            AMBER + "ORACLE OBSERVATION" + RESET,
        ]
        right_lines += wrap(self.observation, max(10, right_w - 4))[:2]

        left_box = self.box("TELEMETRY", left_lines, left_w, panel_h, GREEN2)
        right_box = self.box("SIGNAL", right_lines, right_w, panel_h, CYAN)

        rows = [header, ""]
        for i in range(panel_h):
            rows.append(left_box[i] + "   " + right_box[i])

        rows.append("")
        rows.append(fit(GREEN2 + "FORTUNE //" + RESET, w))
        for fortune_row in fortune_rows:
            rows.append(fit(GREEN2 + "  " + fortune_row + RESET, w))
        for menu_row in menu_rows:
            rows.append(DIM + menu_row + RESET)

        if self.incident:
            phase = int(time.time() * 15) % 8
            if self.incident == "signal_loss":
                row = max(3, len(rows)//2)
                rows[row] = fit(WHITE + BOLD + " NO SIGNAL // REACQUIRING LOCAL REALITY ".center(w, "░") + RESET, w)
            elif self.incident == "memory_leak_theater":
                for n in range(5):
                    row = 3 + n
                    if row < len(rows):
                        rows[row] = fit(RED + f"MEMORY {117+n*83:03d}%  THIS IS FINE" + RESET, w)
            elif self.incident == "cursor_echo":
                row = max(3, len(rows)//2)
                rows[row] = fit(MAGENTA + ("_" * (8 + phase*3)).center(w) + RESET, w)
            elif self.incident == "static_infiltration":
                for row in range(3, min(len(rows)-2, 8)):
                    noise = "".join(self.rng.choice(" .:░▒▓#") for _ in range(max(8, w//3)))
                    rows[row] = fit(DARK + noise + RESET, w)
            else:
                for row in range(3, min(len(rows)-2, 3+phase)):
                    plain = strip_ansi(rows[row])
                    if plain:
                        shift = (phase + row) % max(1, min(16, len(plain)))
                        rows[row] = fit((MAGENTA if row % 2 else RED) + plain[shift:] + plain[:shift] + RESET, w)

        if self.event:
            title, body = self.event
            center = max(4, len(rows)//2 - 1)
            if center < len(rows):
                rows[center] = fit(AMBER + BOLD + (" " + title + " ").center(w, "─") + RESET, w)
            if center + 1 < len(rows):
                rows[center+1] = fit(WHITE + body.center(w) + RESET, w)

        if time.time() < self.panic_until:
            title, body = self.panic
            phase = self.panic_phase
            corruption = [
                RED + BOLD + f" !!! {title} !!! " + RESET,
                MAGENTA + body + RESET,
                AMBER + self.rng.choice([
                    "KERNEL: advisory reality mismatch",
                    "SIGNAL BUS: impossible checksum accepted",
                    "ORACLE CORE: confidence containment active",
                    "CLOCK: several milliseconds are unaccounted for",
                    "FILESYSTEM: behaving professionally under protest",
                ]) + RESET,
                RED + "RECOVERY VECTOR " + ("▓" * (phase + 2)) + ("░" * max(0, 13 - phase)) + RESET,
            ]
            center = max(3, len(rows) // 2 - 2)
            for i, line in enumerate(corruption):
                if center + i < len(rows):
                    rows[center + i] = fit(line.center(w), w)

            if phase % 2 == 0:
                for idx in range(3, min(len(rows) - 2, 3 + phase // 2)):
                    plain = strip_ansi(rows[idx])
                    if plain.strip():
                        shift = 1 + (phase % 5)
                        rows[idx] = MAGENTA + plain[shift:] + plain[:shift] + RESET

        while len(rows) < h:
            rows.append("")
        return "\n".join(safe_row(row, w) for row in rows[:h])


    def render_signal_panel(self, width, height):
        """Conversation-side view of the same persistent Signal Canvas."""
        width = max(24, width)
        height = max(6, height)
        inner_w = max(8, width - 4)
        inner_h = max(3, height - 2)
        active = self.signal.active()
        sampled = self.signal.sample(inner_w, inner_h) if active else None
        scan_row = self.signal.scan_row(inner_h) if sampled else -1
        lines = []
        for y in range(inner_h):
            chars = []
            for x in range(inner_w):
                cell = sampled[y][x] if sampled else None
                if cell:
                    ch, color_name = cell
                    glow = BOLD if y == scan_row else ""
                    chars.append(glow + SignalCanvas.COLORS.get(color_name, CYAN) + ch + RESET)
                else:
                    # A very faint living field makes the pane feel connected
                    # without obscuring model drawings.
                    chars.append(DARK + ("." if (x * 7 + y * 11) % 29 == 0 else " ") + RESET)
            lines.append("".join(chars))
        if active and self.signal.owner:
            title="SIGNAL // THREAD "+str(self.signal.owner)[:9]
        else:
            title="SIGNAL // "+("CANVAS ACTIVE" if active else "LISTENING")
        return self.box(title, lines, width, height, CYAN)

    def render_input(self, w, h, title, subtitle):
        usable = max(30, w - 8)
        lines = [
            "",
            BOLD + CYAN + title + RESET + "   " + DIM + self._model_label() + RESET,
            DIM + subtitle + RESET,
        ]
        if self.deferred_submit:
            lines.append(AMBER + "INTERACTIVE QUEUED // current Oracle call will finish first" + RESET)
        elif not self.online:
            lines.append(RED + "ORACLE OFFLINE // input will not be discarded" + RESET)
        lines.append("")
        prompt = "> " + self.input
        cursor_at = 2 + self.cursor
        shown = prompt
        if len(shown) > usable:
            start = max(0, cursor_at - usable + 4)
            shown = shown[start:start + usable]
            cursor_at -= start

        lines.append(CYAN + "┌" + "─" * (usable + 2) + "┐" + RESET)
        lines.append(CYAN + "│ " + RESET + fit(shown, usable) + CYAN + " │" + RESET)
        lines.append(CYAN + "└" + "─" * (usable + 2) + "┘" + RESET)
        lines += ["", DIM + "[enter] send   [ctrl-u] clear   [esc] return" + RESET]
        pad_top = max(1, (h - len(lines)) // 3)
        frame = [""] * pad_top + ["   " + x for x in lines]
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_answer(self, w, h):
        content = self.answer if self.answer else (AMBER + "ORACLE LINK SYNCHRONIZING…" + RESET)
        wide = w >= 90
        side_w = max(34, (w - 7) // 2) if wide else 0
        body_w = max(30, w - side_w - (7 if wide else 10))
        plain = strip_ansi(content)
        lines = []
        for paragraph in plain.splitlines() or [""]:
            lines.extend(wrap(paragraph, body_w))
        visible = max(5, h - 7)
        max_scroll = max(0, len(lines) - visible)
        self.scroll = min(self.scroll, max_scroll)
        shown = lines[self.scroll:self.scroll + visible]

        frame = [
            BOLD + GREEN + "FUTURE CRASH // ORACLE" + RESET + "   " + DIM + self.oracle.model + RESET,
            DIM + "AUTHORITY " + RESET + GREEN2 + self.host.status() + RESET +
            DIM + "   FILES " + RESET + GREEN2 + "AVAILABLE / ASK" + RESET +
            DIM + "   WEB " + RESET + (GREEN2 if self.host.web_ready else AMBER) + self.host.web_status + RESET +
            DIM + "   THREADS " + RESET + CYAN + str(self.threads.active_count()) + RESET +
            DIM + "   SIGNAL " + RESET +
            (GREEN2 + ("THREAD " + str(self.signal.owner)[:9] if self.signal.owner else "ACTIVE") + RESET
             if self.signal.active() else DARK + "IDLE" + RESET),
            "",
        ]

        if wide:
            panel = self.render_signal_panel(side_w, max(8, h - 5))
            left_rows = ["   " + fit(x, body_w) for x in shown]
            row_count = max(len(left_rows), len(panel))
            for i in range(row_count):
                left = left_rows[i] if i < len(left_rows) else ""
                right = panel[i] if i < len(panel) else ""
                frame.append(fit(left, body_w + 3) + "  " + right)
        else:
            frame.extend("   " + x for x in shown)
            if self.signal.active() and len(frame) < h - 7:
                panel = self.render_signal_panel(min(w - 4, 54), min(10, h - len(frame) - 3))
                frame.extend("  " + row for row in panel)

        while len(frame) < h - 2:
            frame.append("")
        frame.append(DIM + "[↑/↓] scroll   [A] another question   [Q] quit   [ESC] return" + RESET)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_work(self, w, h):
        title = BOLD + AMBER + "FUTURE CRASH // WORKSTATION" + RESET
        status = AMBER + "THINKING" + RESET if self.busy else GREEN + "READY" + RESET
        frame = [
            title + "   " + DIM + self._model_label() + RESET + "   " + status,
            DIM + "persistent conversation // permissioned host operations" + RESET,
            DIM + "MEMORY " + RESET + GREEN2 + self.memory.status() + RESET +
            DIM + "   AUTHORITY " + RESET + GREEN2 + self.host.status() + RESET +
            DIM + "   FILES " + RESET + GREEN2 + "AVAILABLE / ASK" + RESET +
            DIM + "   WEB " + RESET + (GREEN2 if self.host.web_ready else AMBER) + self.host.web_status + RESET,
        ]
        if self.work_notice and time.time() < self.work_notice_until:
            frame.append(GREEN2 + self.work_notice + RESET)
        elif self.thread_notifications:
            frame.append(AMBER + "THREAD // " + self.thread_notifications[-1][:max(20, w-12)] + RESET)
        elif self.host_notice and time.time() < self.host_notice_until:
            frame.append(CYAN + self.host_notice + RESET)
        else:
            self.work_notice = ""
            frame.append("")

        wide = w >= 90
        side_w = max(34, (w - 5) // 2) if wide else 0
        text_w = max(34, w - side_w - 5) if wide else max(30, w - 4)
        body_h = max(7, h - 8)

        transcript = []
        for who, item in self.work_log[-16:]:
            if who == "you":
                tag = CYAN + "YOU" + RESET
            elif who == "host":
                tag = AMBER + "HOST" + RESET
            else:
                tag = GREEN + "ORACLE" + RESET
            transcript.append(tag)
            for line in wrap(strip_ansi(item), max(28, text_w - 4)):
                transcript.append("  " + line)
            transcript.append("")
        transcript = transcript[-body_h:]

        if wide:
            panel = self.render_signal_panel(side_w, body_h)
            row_count = max(body_h, len(panel))
            for i in range(row_count):
                left = transcript[i] if i < len(transcript) else ""
                right = panel[i] if i < len(panel) else ""
                frame.append(fit(left, text_w) + "  " + right)
                if len(frame) >= h - 3:
                    break
        else:
            frame.extend(transcript)
            if self.signal.active() and len(frame) < h - 8:
                panel = self.render_signal_panel(min(w - 2, 50), min(8, h - len(frame) - 3))
                frame.extend(panel)

        while len(frame) < h - 3:
            frame.append("")
        prompt = "> " + self.input + ("_" if not self.busy else "")
        frame.append(fit(prompt, w - 1))
        if self.deferred_submit:
            frame.append(AMBER + "INTERACTIVE QUEUED // current Oracle call will finish first" + RESET)
        else:
            frame.append(DIM + "[enter] send   [ctrl-t] threads   [ctrl-u] clear conversation   [ctrl-k] erase memory   [esc] return" + RESET)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_help(self, w, h):
        sections = [
            ("AMBIENT",
             [
                 ("esc", "real interactive shell; exit or Ctrl-D returns"),
                 ("a", "Quick Oracle"),
                 ("x", "Workstation"),
                 ("t", "Threads"),
                 ("f", "new fortune"),
                 ("r", "new observation"),
                 ("s", "clear Signal drawing"),
                 ("d", "Signal Canvas demo"),
                 ("m", "mute / unmute sound"),
                 ("p", "panic"),
                 ("?", "this help"),
                 ("q", "guarded quit"),
             ]),
            ("WORKSTATION",
             [
                 ("enter", "send"),
                 ("ctrl-t", "Threads"),
                 ("ctrl-u", "clear current conversation; keep persistent memory"),
                 ("ctrl-k", "guarded persistent-memory erase"),
                 ("esc", "return to Ambient"),
             ]),
            ("THREADS",
             [
                 ("enter", "details"),
                 ("j/k or arrows", "select"),
                 ("d", "toggle built-in 4-minute Signal Dream"),
                 ("p", "pause selected Thread"),
                 ("r", "resume selected Thread"),
                 ("x", "cancel selected Thread"),
                 ("esc", "return"),
             ]),
            ("CONCEPTS",
             [
                 ("MEMORY", "one rolling long memory + eight recent Workstation exchanges"),
                 ("WEB", "Ollama hosted web search when OLLAMA_API_KEY is available"),
                 ("FILES", "permissioned host actions with verified HOST RECEIPTS"),
                 ("SIGNAL", "shared expressive drawing surface + render feedback + tiny animation"),
                 ("MODEL WAKE", "model-only recurring Thread action for Signal art, notes, moods, etc."),
                 ("LOOK", "optional separate project; detected if `lk` is already on PATH"),
             ]),
        ]

        body = []
        for title, items in sections:
            body.append(AMBER + title + RESET)
            for key, desc in items:
                body.append(fit(f"  {key:<15}{desc}", w - 1))
            body.append("")

        header_rows = 3
        footer_rows = 2
        visible = max(4, h - header_rows - footer_rows)

        max_scroll = max(0, len(body) - visible)
        self.help_scroll = max(0, min(self.help_scroll, max_scroll))
        shown = body[self.help_scroll:self.help_scroll + visible]

        frame = [
            BOLD + CYAN + f"FUTURE CRASH // HELP // {VERSION}" + RESET,
            DIM + "canonical command reference" + RESET,
            "",
        ]
        frame.extend(shown)

        while len(frame) < h - 2:
            frame.append("")

        if max_scroll:
            start_line = self.help_scroll + 1
            end_line = min(len(body), self.help_scroll + visible)
            pos = f"{start_line}-{end_line}/{len(body)}"
            controls = f"[↑/↓ j/k] scroll   [pgup/pgdn or space] page   [home/g] top   [esc/?/h/q] return   {pos}"
        else:
            controls = "[esc / ? / h / q] return"

        frame.append(DIM + fit(controls, w - 1) + RESET)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_threads(self, w, h):
        tasks = [t for t in self.threads.tasks if t.get("state") != "cancelled"]
        self.thread_selected = min(self.thread_selected, max(0, len(tasks) - 1))
        frame = [
            BOLD + CYAN + "FUTURE CRASH // THREADS" + RESET,
            DIM + "persistent internal scheduler // exact approved actions // one wake at a time" + RESET,
            "",
        ]

        if not tasks:
            frame += [
                DIM + "No Threads are currently defined." + RESET,
                "",
                "Press D for the built-in Signal Dream, or ask the Oracle something like:",
                GREEN2 + '  "Every 10 minutes, search the web for changes to flight UA1734."' + RESET,
            ]
        else:
            now = time.time()
            header = f"{'':2} {'ID':9} {'STATE':8} {'EVERY':6} {'NEXT':10} {'RUNS':5} TITLE"
            frame.append(DIM + header + RESET)
            frame.append(DIM + "─" * min(w - 1, 88) + RESET)
            for i, task in enumerate(tasks[:18]):
                selected = i == self.thread_selected
                marker = "▶" if selected else " "
                state = str(task.get("state", "?")).upper()
                row = (
                    f"{marker} {task.get('id','')[:9]:9} {state:8} "
                    f"{ThreadStore.interval_text(task.get('every_seconds',300)):6} "
                    f"{ThreadStore.countdown_text(task, now):10} "
                    f"{int(task.get('runs',0)):5} "
                    f"{task.get('title','')[:max(10, w-50)]}"
                )
                frame.append((WHITE + BOLD if selected else GREEN2) + fit(row, w - 1) + RESET)

            task = tasks[self.thread_selected]
            frame += ["", AMBER + "PURPOSE" + RESET]
            frame += ["  " + x for x in wrap(str(task.get("purpose", "")), max(30, w - 6))[:3]]

            last_run = task.get("last_run")
            last_clock = time.strftime("%H:%M:%S", time.localtime(last_run)) if last_run else "NEVER"
            changed = task.get("last_changed")
            change_text = "CHANGED" if changed is True else ("QUIET" if changed is False else "UNKNOWN")
            frame += [
                "",
                AMBER + "LAST RUN" + RESET +
                f"  {last_clock}   {task.get('last_result','NOT RUN')}   {change_text}   RUN #{int(task.get('runs',0))}",
                AMBER + "LAST" + RESET + "      " +
                (str(task.get("last_summary", ""))[:max(20, w - 14)] or "(not interpreted yet)"),
                AMBER + "SIGNAL" + RESET + "    " +
                ("OWNED / PERSISTENT" if self.signal.owner == task.get("id") and self.signal.active() else "—"),
            ]

            if self.thread_detail:
                action = json.dumps(task.get("action", {}), ensure_ascii=False)
                receipt = " ".join(str(task.get("last_receipt", "")).split())
                frame += [
                    "",
                    CYAN + "ACTION" + RESET,
                ]
                frame += ["  " + x for x in wrap(action, max(30, w - 6))[:3]]
                frame += [CYAN + "LAST RECEIPT" + RESET]
                frame += ["  " + x for x in wrap(receipt or "(none)", max(30, w - 6))[:3]]

        while len(frame) < h - 3:
            frame.append("")
        dream=self.threads.dream_task()
        dream_state="ON" if dream and dream.get("state")=="active" else "OFF"
        frame.append(DIM + f"[d] dream {dream_state}   [enter] details   [j/k or ↑/↓] select   [p] pause   [r] resume   [x] cancel   [esc] return" + RESET)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_tool_approval(self, w, h):
        request = self.pending_tool or {"name": "unknown"}
        capability = self.host.capability(request)
        description = self.host.describe(request)
        box_w = min(82, max(54, w - 10))
        lines = [
            "",
            AMBER + BOLD + (
                "ORACLE REQUESTS THREAD CHANGE"
                if request.get("name") == "thread_update"
                else "ORACLE REQUESTS HOST ACCESS"
            ) + RESET,
            "",
            "CAPABILITY  " + WHITE + capability + RESET,
            "",
        ]
        lines.extend(wrap(description, box_w - 8)[:5])
        lines += [
            "",
            DIM + "The model proposed this. Python has not performed it yet." + RESET,
            DIM + "A HOST RECEIPT will verify success or failure afterward." + RESET,
            "",
            BOLD + "[Y / ENTER] ALLOW ONCE" + RESET,
        ]
        if capability == "TASK AUTHORITY":
            lines.append(DIM + "[S] same as Y // this exact Thread is the persistent permission" + RESET)
        elif capability == "RUN COMMANDS":
            lines.append(DIM + "[S] same as once for commands (never persistent)" + RESET)
        else:
            lines.append(BOLD + "[S] ALLOW THIS CAPABILITY FOR SESSION" + RESET)
        lines += [
            RED + "[N / ESC] DENY" + RESET,
        ]
        boxed = self.box("HOST INTERLOCK", lines, box_w, min(h - 2, 19), AMBER)
        left = max(0, (w - box_w) // 2)
        top = max(0, (h - len(boxed)) // 2)
        frame = [""] * top
        frame.extend((" " * left) + row for row in boxed)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_memory_clear(self, w, h):
        box_w = min(68, max(48, w - 12))
        lines = [
            "",
            RED + BOLD + "PERSISTENT MEMORY ERASE" + RESET,
            "",
            "This deletes the rolling long memory and all recent memory slots.",
            "The current Workstation transcript is not the same thing.",
            "",
            AMBER + "Erase persistent Future Crash memory?" + RESET,
            "",
            BOLD + "[Y] ERASE MEMORY" + RESET,
            DIM + "[N / ESC] KEEP MEMORY" + RESET,
        ]
        boxed = self.box("MEMORY INTERLOCK", lines, box_w, min(h - 4, 16), RED)
        left = max(0, (w - box_w) // 2)
        top = max(0, (h - len(boxed)) // 2)
        frame = [""] * top
        frame.extend((" " * left) + line for line in boxed)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

    def render_quit(self, w, h):
        box_w = min(64, max(44, w - 12))
        lines = [
            "",
            RED + BOLD + "SHUTDOWN REQUEST" + RESET,
            "",
            "Future Crash is still running.",
            DIM + "esc from Ambient opens a real shell without quitting." + RESET,
            "No emergency has been detected.",
            "",
            AMBER + "Terminate the workstation anyway?" + RESET,
            "",
            BOLD + "[Y / ENTER] SHUT DOWN" + RESET,
            DIM + "[N / ESC] RETURN SAFELY" + RESET,
        ]
        boxed = self.box("SYSTEM INTERLOCK", lines, box_w, min(h - 4, 16), RED)
        left = max(0, (w - box_w) // 2)
        top = max(0, (h - len(boxed)) // 2)
        frame = [""] * top
        frame.extend((" " * left) + line for line in boxed)
        while len(frame) < h:
            frame.append("")
        return "\n".join(safe_row(row, w) for row in frame[:h])

# ---------- CLI ----------

LOCAL_OLLAMA_URL = "http://127.0.0.1:11434"


def _look_selected_ollama_host():
    """Reuse LOOK's selected Ollama host without importing LOOK itself."""
    path=Path.home()/".local"/"share"/"look"/"ollama_hosts.json"
    try:
        data=json.loads(path.read_text(encoding="utf-8"))
        default=str(data.get("default") or "local")
        if default=="local":
            return LOCAL_OLLAMA_URL
        hosts=data.get("hosts") or {}
        item=hosts.get(default) if isinstance(hosts,dict) else None
        url=str((item or {}).get("url") or "").strip()
        if url:
            return url.rstrip("/")
    except (OSError,ValueError,TypeError,json.JSONDecodeError):
        pass
    return LOCAL_OLLAMA_URL


def _look_active_model():
    """Read LOOK's shared active model. This is the default for every FC inference."""
    path=Path.home()/".local"/"share"/"look"/"ollama_model"
    try:
        model=path.read_text(encoding="utf-8").strip()
        if model:
            return model
    except OSError:
        pass
    return "qwen3:8b"


def parse_args():
    p = argparse.ArgumentParser(
        description="Future Crash // Zero — local AI workstation / ambient terminal",
        epilog="Ambient: esc shell · a ask · x workstation · t threads · m mute · ? help · q quit",
    )
    p.add_argument("--version", action="version", version=f"Future Crash {VERSION}")
    p.add_argument("--model", default=None, help="Ollama model (default: LOOK selected model, then qwen3:8b)")
    p.add_argument("--ollama", default=None, help="Ollama base URL (default: LOOK selected host, then localhost)")
    p.add_argument("--fps", type=int, default=12, help="UI refresh rate (default: 12)")
    p.add_argument("--no-ai-ambient", action="store_true", help="disable ambient LLM observations")
    p.add_argument("--no-audio", action="store_true", help="disable synthesized terminal sounds for this launch (overrides saved audio preference)")
    return p.parse_args()

if __name__ == "__main__":
    if os.name != "posix":
        print("Future Crash Zero currently targets macOS and Linux terminals.")
        raise SystemExit(1)
    args = parse_args()
    if not args.ollama:
        args.ollama=_look_selected_ollama_host()
    args.follow_look_model = not bool(args.model)
    if not args.model:
        args.model=_look_active_model()
    app = FutureCrash(args)
    try:
        app.start()
    except KeyboardInterrupt:
        pass
